/* ============================================================================
 * Copyright (c) Texas Instruments Incorporated 2009
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

/**
 *  @file   csl_tac_regsBEAux.h
 *
 *  @brief  This file contains the enumerations, type definitions and function
 *          declarations for the CSL function layer for the TAC Back-End
 *          interface.
 *
 *  @date   09-Jan-2009
 *  @author Vijay Pothukuchi
 *
 *  \par
 *  ============================================================================
 *  @n   (C) Copyright 2009, Texas Instruments, Inc.
 *  @n   Use of this software is controlled by the terms and conditions found 
 *  @n   in the license agreement under which this software has been supplied.
 *  ===========================================================================
 *  \par 
 */

/* =============================================================================
 *  Revision History
 *  ===============
 *  09-Jan-2009   VP    File Created
 * =============================================================================
 */

/**
@defgroup CSL_TAC_BE_API TAC Back-End 
*/

/**
@defgroup CSL_TAC_BE_ENUM TAC Back-End Enumerated Data Types
@ingroup CSL_TAC_BE_API
*/

/**
@defgroup CSL_TAC_BE_DATASTRUCT TAC Back-End Data Structures
@ingroup CSL_TAC_BE_API
*/

/**
@defgroup CSL_TAC_BE_FUNCTION TAC Back-End Functions
@ingroup CSL_TAC_BE_API
*/

#ifndef _CSL_TAC_BE_AUX_H_
#define _CSL_TAC_BE_AUX_H_

#include <ti/csl/csl_tac_regs.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/** @addtogroup CSL_TAC_BE_ENUM
@{
*/

/**
 *  @brief   Enumeration for specifying \a CSL_TAC_BETI_getEnableStatus output.
 *
 */
typedef enum
{
    /** The BETI is disabled. */
	CSL_TAC_BETI_Disabled  = 0,

    /** The BETI is enabled. */
	CSL_TAC_BETI_Enabled   = 1

} CSL_TAC_BETI_enableStatus;

/**
 *  @brief   Enumeration for specifying \a CSL_TAC_BEII_getEnableStatus output.
 *
 */
typedef enum
{
    /** The BEII is disabled. */
	CSL_TAC_BEII_Disabled  = 0,

    /** The BEII is enabled. */
	CSL_TAC_BEII_Enabled   = 1

} CSL_TAC_BEII_enableStatus;

/**
 *  @brief   Enumeration for the SGCP status.
 *
 */
typedef enum
{
    /** SGCP is Idle */
    CSL_TAC_BETI_statusBit_Idle,

    /** SGCP is Busy */
    CSL_TAC_BETI_statusBit_Busy

} CSL_TAC_BETI_statusBit;

/**
 *  @brief   Enumeration for specifying 
 *           \a CSL_TAC_BETI_getWatchDogInterruptStatus output.
 *
 */
typedef enum
{
    /** No interrupt has been generated. */
    CSL_TAC_BETI_wdInterruptStatus_NoInt = 0,

    /** An interrupt has been generated and forwarded to the BEII. */
    CSL_TAC_BETI_wdInterruptStatus_Int   = 1

} CSL_TAC_BETI_wdInterruptStatus;

/**
 *  @brief   Enumeration for specifying \a CSL_TAC_getStrmPwrMeasMode output.
 *
 */
typedef enum
{
    /** The stream power accumulation length is 1 slot (2560 chips). */
	CSL_TAC_BE_strmPwrMeasMode_SlotMode   = 0,

    /** The stream power accumulation length is 1 Symbol (256 chips). */
	CSL_TAC_BE_strmPwrMeasMode_SymbolMode = 1

} CSL_TAC_BE_strmPwrMeasMode;

/**
@}
*/

/** @addtogroup CSL_TAC_BE_DATASTRUCT
@{
*/

/**
 *  @brief   The descriptor specifies the parameters obtained from the
 *           BETI status register.
 */
typedef struct
{
    /** Status of the SGCP 0 */
    CSL_TAC_BETI_statusBit  sgcp0Status;

    /** Status of the SGCP 1 */
    CSL_TAC_BETI_statusBit  sgcp1Status;

} CSL_TAC_BETI_status;

/**
 *  @brief   This descriptor specifies the parameters obtained from the
 *           interrupt status register.
 */
typedef struct
{
    /** Denotes the SGCP0 Cycle Overflow status. */
    Uint8 sgcp0CycOverStat;

    /** Denotes the SGCP0 FIFO Overflow status. */
    Uint8 sgcp0FifoOverStat;

    /** Denotes the SGCP0 Sequencer Idle status. */
    Uint8 sgcp0SeqStat;

    /** Denotes the SGCP0 Input Buffer Miss status. */
    Uint8 sgcp0BuffMissStat;

    /** Denotes the SGCP1 Cycle Overflow status. */
    Uint8 sgcp1CycOverStat;

    /** Denotes the SGCP1 FIFO Overflow status. */
    Uint8 sgcp1FifoOverStat;

    /** Denotes the SGCP1 Sequencer Idle status. */
    Uint8 sgcp1SeqStat;

    /** Denotes the SGCP1 Input Buffer Miss status. */
    Uint8 sgcp1BuffMissStat;

    /** Denotes the BETI Watchdog status. */
    Uint8 betiWdStat;

    /** FE transaction error status */
    Uint8 feTransErrStat;

} CSL_TAC_BEII_interruptStatus;

/**
 *  @brief   This descriptor specifies the parameters required to setup a
 *           timestamp.
 *
 */
typedef struct
{
    /** Specifies the Chip value. */
    Uint16 chipId;

    /** Specifies the Frame value. */
    Uint16 frameId;

    /** Specifies the Slot value. */
    Uint8  slotId;
} CSL_TAC_BE_Timestamp_req;

/**
@}
*/


/******************************************************************************
 * TAC global function declarations
 *****************************************************************************/

/* =============================================================================
 * Functions linked to BETI management
 * =============================================================================
 */

extern void CSL_TAC_BETI_enable();

extern void CSL_TAC_BETI_disable();

extern CSL_TAC_BETI_enableStatus CSL_TAC_BETI_getEnableStatus();

extern void CSL_TAC_BETI_getStatus(
	CSL_TAC_BETI_status * betiStatus
);

extern void CSL_TAC_BETI_setWatchDog(
	Uint16 reloadCnt
);

extern Uint16 CSL_TAC_BETI_getWatchDogStatus();

extern CSL_TAC_BETI_wdInterruptStatus CSL_TAC_BETI_getWatchDogInterruptStatus();

extern void CSL_TAC_BETI_clearWatchDogInterrupt();

/* =============================================================================
 * Functions linked to BEII management
 * =============================================================================
 */

extern void CSL_TAC_BEII_enable();

extern void CSL_TAC_BEII_disable();

extern CSL_TAC_BEII_enableStatus CSL_TAC_BEII_getEnableStatus();

extern void CSL_TAC_BEII_getInterruptStatus(
	CSL_TAC_BEII_interruptStatus * interruptStatus
);

extern void CSL_TAC_BEII_getEnabledInterruptStatus(
	CSL_TAC_BEII_interruptStatus * interruptEnStatus
);

extern void CSL_TAC_BEII_forceInterrupts(
	CSL_TAC_BEII_interruptStatus * interruptsToForce
);

extern void CSL_TAC_BEII_clearInterrupts(
	CSL_TAC_BEII_interruptStatus * interruptsToClear
);

extern void CSL_TAC_BEII_enableInterrupts(
	CSL_TAC_BEII_interruptStatus * interruptsToEnable
);

extern void CSL_TAC_BEII_disableInterrupts(
	CSL_TAC_BEII_interruptStatus * interruptsToDisable
);

extern void CSL_TAC_BEII_setEOI(
	Uint32 eoiVecValue
);

extern Uint32 CSL_TAC_BEII_getEOI();

extern CSL_TAC_BE_strmPwrMeasMode CSL_TAC_BE_getStrmPwrMeasMode();

extern void CSL_TAC_BE_setSwIterStart();

extern void CSL_TAC_BE_setTimestamp(
	CSL_TAC_BE_Timestamp_req * timestamp
);

extern void CSL_TAC_BE_getTimestamp(
	CSL_TAC_BE_Timestamp_req * timestamp
);


#ifdef __cplusplus
}
#endif // __cplusplus

#endif // _CSL_TAC_BE_AUX_H_

