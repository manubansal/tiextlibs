/********************************************************************
* Copyright (C) 2003-2008 Texas Instruments Incorporated.
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
#ifndef _CSLR_ENC_MMR_H_
#define _CSLR_ENC_MMR_H_

#include <ti/csl/cslr.h>
#include <ti/csl/tistdtypes.h>
#include <ti/csl/cslr_bcp_common_mmr.h>


/* Minimum unit = 1 byte */

/**************************************************************************\
* Register Overlay Structure
\**************************************************************************/

typedef struct  {
    volatile Uint32 POLY_COEF1;
    volatile Uint32 POLY_COEF2;
    volatile Uint32 POLY_COEF3;
    volatile Uint32 SCRINIT0;
    volatile Uint32 SCRPOLY0;
    volatile Uint32 CRC24_INIT0;
    volatile Uint32 CRC24_POLY0;
    volatile Uint32 SCRINIT1;
    volatile Uint32 SCRPOLY1;
    volatile Uint32 CRC16_INIT1;
    volatile Uint32 CRC16_POLY1;
    volatile Uint32 SCRINIT2;
    volatile Uint32 SCRPOLY2;
    CSL_Bcp_IntRegs IntRegs[4];
    CSL_Bcp_DataLoggerRegs DlgRegs;
} CSL_Enc_mmrRegs;

/**************************************************************************\
* Field Definition Macros
\**************************************************************************/

/* POLY_COEF1 */

#define CSL_ENC_MMR_POLY_COEF1_POLYCOEF1_MASK (0xFFFFFFFFu)
#define CSL_ENC_MMR_POLY_COEF1_POLYCOEF1_SHIFT (0x00000000u)
#define CSL_ENC_MMR_POLY_COEF1_POLYCOEF1_RESETVAL (0x00000000u)

#define CSL_ENC_MMR_POLY_COEF1_RESETVAL  (0x004D9413u)

/* POLY_COEF2 */

#define CSL_ENC_MMR_POLY_COEF2_POLYCOEF2_MASK (0xFFFFFFFFu)
#define CSL_ENC_MMR_POLY_COEF2_POLYCOEF2_SHIFT (0x00000000u)
#define CSL_ENC_MMR_POLY_COEF2_POLYCOEF2_RESETVAL (0x00000000u)

#define CSL_ENC_MMR_POLY_COEF2_RESETVAL  (0x00D5AA5Fu)

/* POLY_COEF3 */

#define CSL_ENC_MMR_POLY_COEF3_POLYCOEF3_MASK (0xFFFFFFFFu)
#define CSL_ENC_MMR_POLY_COEF3_POLYCOEF3_SHIFT (0x00000000u)
#define CSL_ENC_MMR_POLY_COEF3_POLYCOEF3_RESETVAL (0x00000000u)

#define CSL_ENC_MMR_POLY_COEF3_RESETVAL  (0x00DDC3C0u)

/* SCRINIT0 */

#define CSL_ENC_MMR_SCRINIT0_SCRINIT0_MASK (0xFFFF0000u)
#define CSL_ENC_MMR_SCRINIT0_SCRINIT0_SHIFT (0x00000010u)
#define CSL_ENC_MMR_SCRINIT0_SCRINIT0_RESETVAL (0x00000000u)

#define CSL_ENC_MMR_SCRINIT0_RESETVAL     (0x00000000u)

/* SCRPOLY0 */

#define CSL_ENC_MMR_SCRPOLY0_SCRPOLY0_MASK (0xFFFF0000u)
#define CSL_ENC_MMR_SCRPOLY0_SCRPOLY0_SHIFT (0x00000010u)
#define CSL_ENC_MMR_SCRPOLY0_SCRPOLY0_RESETVAL (0x00000000u)

#define CSL_ENC_MMR_SCRPOLY0_SCRPOLY     (0x00000000u)

/* CRC24_INIT0 */

#define CSL_ENC_MMR_CRC24_INIT0_CRC24INIT0_MASK (0xFFFFFF00u)
#define CSL_ENC_MMR_CRC24_INIT0_CRC24INIT0_SHIFT (0x00000008u)
#define CSL_ENC_MMR_CRC24_INIT0_CRC24INIT0_RESETVAL (0x00000000u)

#define CSL_ENC_MMR_CRC24_INIT0_RESETVAL     (0x00000000u)

/* CRC24_POLY0 */

#define CSL_ENC_MMR_CRC24_POLY0_CRC24POLY0_MASK (0xFFFFFF00u)
#define CSL_ENC_MMR_CRC24_POLY0_CRC24POLY0_SHIFT (0x00000008u)
#define CSL_ENC_MMR_CRC24_POLY0_CRC24POLY0_RESETVAL (0x00000000u)

#define CSL_ENC_MMR_CRC24_POLY0_RESETVAL     (0x80006300u)

/* SCRINIT1 */

#define CSL_ENC_MMR_SCRINIT1_SCRINIT1_MASK (0xFFFF0000u)
#define CSL_ENC_MMR_SCRINIT1_SCRINIT1_SHIFT (0x00000010u)
#define CSL_ENC_MMR_SCRINIT1_SCRINIT1_RESETVAL (0x00000000u)

#define CSL_ENC_MMR_SCRINIT1_RESETVAL     (0x6E2A0000)

/* SCRPOLY1 */

#define CSL_ENC_MMR_SCRPOLY1_SCRPOLY1_MASK (0xFFFF0000u)
#define CSL_ENC_MMR_SCRPOLY1_SCRPOLY1_SHIFT (0x00000010u)
#define CSL_ENC_MMR_SCRPOLY1_SCRPOLY1_RESETVAL (0x00000000u)

#define CSL_ENC_MMR_SCRPOLY1_RESETVAL     (0x00060000)

/* CRC16_INIT1 */

#define CSL_ENC_MMR_CRC16_INIT1_CRC16INIT1_MASK (0xFFFF0000u)
#define CSL_ENC_MMR_CRC16_INIT1_CRC16INIT1_SHIFT (0x00000010u)
#define CSL_ENC_MMR_CRC16_INIT1_CRC16INIT1_RESETVAL (0x00000000u)

#define CSL_ENC_MMR_CRC16_INIT1_RESETVAL     (0x00000000u)

/* CRC16_POLY1 */

#define CSL_ENC_MMR_CRC16_POLY1_CRC16POLY1_MASK (0xFFFF0000u)
#define CSL_ENC_MMR_CRC16_POLY1_CRC16POLY1_SHIFT (0x00000010u)
#define CSL_ENC_MMR_CRC16_POLY1_CRC16POLY1_RESETVAL (0x00000000u)

#define CSL_ENC_MMR_CRC16_POLY1_RESETVAL     (0x10210000u)

/* SCRINIT2 */

#define CSL_ENC_MMR_SCRINIT2_SCRINIT2_MASK (0xFFFF0000u)
#define CSL_ENC_MMR_SCRINIT2_SCRINIT2_SHIFT (0x00000010u)
#define CSL_ENC_MMR_SCRINIT2_SCRINIT2_RESETVAL (0x00000000u)

#define CSL_ENC_MMR_SCRINIT2_RESETVAL     (0x6E2A0000)

/* SCRPOLY2 */

#define CSL_ENC_MMR_SCRPOLY2_SCRPOLY2_MASK (0xFFFF0000u)
#define CSL_ENC_MMR_SCRPOLY2_SCRPOLY2_SHIFT (0x00000010u)
#define CSL_ENC_MMR_SCRPOLY2_SCRPOLY2_RESETVAL (0x00000000u)

#define CSL_ENC_MMR_SCRPOLY2_RESETVAL     (0x00060000)

#endif
