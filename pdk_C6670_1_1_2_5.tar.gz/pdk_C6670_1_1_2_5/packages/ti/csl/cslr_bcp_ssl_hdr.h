/********************************************************************
* Copyright (C) 2003-2008 Texas Instruments Incorporated.
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
#ifndef _CSLR_SSL_HDR_H_
#define _CSLR_SSL_HDR_H_

#include <ti/csl/cslr.h>
#include <ti/csl/tistdtypes.h>


/* Minimum unit = 1 byte */

/**************************************************************************\
* Register Overlay Structure
\**************************************************************************/

/**************************************************************************\
* Field Definition Macros
\**************************************************************************/

/* IMPORTANT NOTE: The local headers for SSL change word order based on the
*  radio standard (LTE, WCDMA, WiMax), split mode for LTE and FDD or TDD for
*  WCDMA. All the definitions below show the actual word positions for the
*  modes that they are used in. */

/* Word 0 (common part, LTE, WCDMA and WiMax) */
#define CSL_SSL_HDR_WORD0_LOCAL_HDR_LEN_MASK (0x000000FFu)
#define CSL_SSL_HDR_WORD0_LOCAL_HDR_LEN_SHIFT (0x00000000u)
#define CSL_SSL_HDR_WORD0_LOCAL_HDR_LEN_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD0_MOD_ID_MASK    (0x00000F00u)
#define CSL_SSL_HDR_WORD0_MOD_ID_SHIFT   (0x00000008u)
#define CSL_SSL_HDR_WORD0_MOD_ID_RESETVAL (0x00000000u)

/* Word 0 (LTE and WiMax) */
#define CSL_SSL_HDR_WORD0_UVA_MASK    (0xFFFF0000u)
#define CSL_SSL_HDR_WORD0_UVA_SHIFT   (0x00000010u)
#define CSL_SSL_HDR_WORD0_UVA_RESETVAL (0x00000000u)

/* Word 0 (FDD WCDMA (TDD WCDMA bits are reserved) */
#define CSL_SSL_HDR_WORD0_WCDMA_SYMB_SEG_MASK    (0x3FFF0000u)
#define CSL_SSL_HDR_WORD0_WCDMA_SYMB_SEG_SHIFT   (0x00000010u)
#define CSL_SSL_HDR_WORD0_WCDMA_SYMB_SEG_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD0_RESETVAL       (0x00000000u)

/* Word 1 (LTE, WCDMA and WiMax) */
#define CSL_SSL_HDR_WORD1_FDD_TDD_SEL_MASK (0x00000001u)
#define CSL_SSL_HDR_WORD1_FDD_TDD_SEL_SHIFT (0x00000000u)
#define CSL_SSL_HDR_WORD1_FDD_TDD_SEL_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD1_SPLIT_MODE_EN_MASK (0x00000002u)
#define CSL_SSL_HDR_WORD1_SPLIT_MODE_EN_SHIFT (0x00000001u)
#define CSL_SSL_HDR_WORD1_SPLIT_MODE_EN_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD1_JACK_BIT_MASK  (0x00000004u)
#define CSL_SSL_HDR_WORD1_JACK_BIT_SHIFT (0x00000002u)
#define CSL_SSL_HDR_WORD1_JACK_BIT_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD1_LTE_DESCRAM_EN_MASK (0x00000008u)
#define CSL_SSL_HDR_WORD1_LTE_DESCRAM_EN_SHIFT (0x00000003u)
#define CSL_SSL_HDR_WORD1_LTE_DESCRAM_EN_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD1_MOD_TYPE_SEL_MASK (0x00000070u)
#define CSL_SSL_HDR_WORD1_MOD_TYPE_SEL_SHIFT (0x00000004u)
#define CSL_SSL_HDR_WORD1_MOD_TYPE_SEL_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD1_TDD_OUTPUT_PACK_MASK   (0x00000080u)
#define CSL_SSL_HDR_WORD1_TDD_OUTPUT_PACK_SHIFT  (0x00000007u)
#define CSL_SSL_HDR_WORD1_TDD_OUTPUT_PACK_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD1_CMUX_LN_MASK   (0x00000300u)
#define CSL_SSL_HDR_WORD1_CMUX_LN_SHIFT  (0x00000008u)
#define CSL_SSL_HDR_WORD1_CMUX_LN_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD1_Q_FORMAT_MASK  (0x00000C00u)
#define CSL_SSL_HDR_WORD1_Q_FORMAT_SHIFT (0x0000000Au)
#define CSL_SSL_HDR_WORD1_Q_FORMAT_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD1_B_TABLE_INDEX_MASK  (0x0007F000u)
#define CSL_SSL_HDR_WORD1_B_TABLE_INDEX_SHIFT (0x0000000Cu)
#define CSL_SSL_HDR_WORD1_B_TABLE_INDEX_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD1_TTI_2MS_SEL_MASK  (0x00080000u)
#define CSL_SSL_HDR_WORD1_TTI_2MS_SEL_SHIFT (0x00000013u)
#define CSL_SSL_HDR_WORD1_TTI_2MS_SEL_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD1_WCDMA_NUM_SLOTS_MASK  (0x00700000u)
#define CSL_SSL_HDR_WORD1_WCDMA_NUM_SLOTS_SHIFT (0x00000014u)
#define CSL_SSL_HDR_WORD1_WCDMA_NUM_SLOTS_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD1_WCDMA_NUM_PHYCH_MASK  (0x03800000u)
#define CSL_SSL_HDR_WORD1_WCDMA_NUM_PHYCH_SHIFT (0x00000017u)
#define CSL_SSL_HDR_WORD1_WCDMA_NUM_PHYCH_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD1_RMUX_LN_INDEX_MASK   (0xFC000000u)
#define CSL_SSL_HDR_WORD1_RMUX_LN_INDEX_SHIFT  (0x0000001Au)
#define CSL_SSL_HDR_WORD1_RMUX_LN_INDEX_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD1_RESETVAL       (0x00000000u)

/* Word 2 (LTE) */
#define CSL_SSL_HDR_WORD2_RI_LN_MASK   (0x00003FFFu)
#define CSL_SSL_HDR_WORD2_RI_LN_SHIFT  (0x00000000u)
#define CSL_SSL_HDR_WORD2_RI_LN_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD2_ACK_LN_MASK    (0x3FFF0000u)
#define CSL_SSL_HDR_WORD2_ACK_LN_SHIFT   (0x00000010u)
#define CSL_SSL_HDR_WORD2_ACK_LN_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD2_RESETVAL       (0x00000000u)

/* Word 3 (LTE) */
#define CSL_SSL_HDR_WORD3_CINIT_P2_MASK     (0x7FFFFFFFu)
#define CSL_SSL_HDR_WORD3_CINIT_P2_SHIFT    (0x00000000u)
#define CSL_SSL_HDR_WORD3_CINIT_P2_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORD3_RESETVAL       (0x00000000u)

/* WCDMA FDD UVA (words 2-4, 11-13) */
/* X = UVA 0,2,4,6,8,10. Y = UVA 1,3,5,7,9,11 */
#define CSL_SSL_HDR_WORDX_FDD_UVA_Y_MASK     (0x0000FFFFu)
#define CSL_SSL_HDR_WORDX_FDD_UVA_Y_SHIFT    (0x00000000u)
#define CSL_SSL_HDR_WORDX_FDD_UVA_Y_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORDX_FDD_UVA_X_MASK     (0xFFFF0000u)
#define CSL_SSL_HDR_WORDX_FDD_UVA_X_SHIFT    (0x00000010u)
#define CSL_SSL_HDR_WORDX_FDD_UVA_X_RESETVAL (0x00000000u)

/* WCDMA TDD Slot Config (cfg 0-5 are words 2,4,6,8,10,12) */
#define CSL_SSL_HDR_WORDX_WCDMA_SIZE_SLOT_X_MASK     (0x00000FFFu)
#define CSL_SSL_HDR_WORDX_WCDMA_SIZE_SLOT_X_SHIFT    (0x00000000u)
#define CSL_SSL_HDR_WORDX_WCDMA_SIZE_SLOT_X_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORDX_TDD_UVA_X_MASK     (0xFFFF0000u)
#define CSL_SSL_HDR_WORDX_TDD_UVA_X_SHIFT    (0x00000010u)
#define CSL_SSL_HDR_WORDX_TDD_UVA_X_RESETVAL (0x00000000u)

/* Scale C0_N  (N = 0 to 11) */
/* LTE:   X = 4 to 15        */
/* WCDMA: X = 5-10,14-19 (FDD) or 3,5,7,9,11,13 (TDD) */
#define CSL_SSL_HDR_WORDX_SCALE_C0_N_MASK     (0xFFFFFFFFu)
#define CSL_SSL_HDR_WORDX_SCALE_C0_N_SHIFT    (0x00000000u)
#define CSL_SSL_HDR_WORDX_SCALE_C0_N_RESETVAL (0x00000000u)

#define CSL_SSL_HDR_WORDX_RESETVAL       (0x00000000u)

/* Scale C1_N  (N = 0 to 11) */
/* LTE: X = 16 to 27 (split mode only) */
#define CSL_SSL_HDR_WORDX_SCALE_C1_N_MASK     (0xFFFFFFFFu)
#define CSL_SSL_HDR_WORDX_SCALE_C1_N_SHIFT    (0x00000000u)
#define CSL_SSL_HDR_WORDX_SCALE_C1_N_RESETVAL (0x00000000u)

#endif
