/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B21
 */
import java.util.*;
import org.mozilla.javascript.*;
import xdc.services.intern.xsr.*;
import xdc.services.spec.Session;

public class ti_instrumentation_wdtimer
{
    static final String VERS = "@(#) xdc-B21\n";

    static final Proto.Elm $$T_Bool = Proto.Elm.newBool();
    static final Proto.Elm $$T_Num = Proto.Elm.newNum();
    static final Proto.Elm $$T_Str = Proto.Elm.newStr();
    static final Proto.Elm $$T_Obj = Proto.Elm.newObj();

    static final Proto.Fxn $$T_Met = new Proto.Fxn(null, null, 0, -1, false);
    static final Proto.Map $$T_Map = new Proto.Map($$T_Obj);
    static final Proto.Arr $$T_Vec = new Proto.Arr($$T_Obj);

    static final XScriptO $$DEFAULT = Value.DEFAULT;
    static final Object $$UNDEF = Undefined.instance;

    static final Proto.Obj $$Package = (Proto.Obj)Global.get("$$Package");
    static final Proto.Obj $$Module = (Proto.Obj)Global.get("$$Module");
    static final Proto.Obj $$Instance = (Proto.Obj)Global.get("$$Instance");
    static final Proto.Obj $$Params = (Proto.Obj)Global.get("$$Params");

    static final Object $$objFldGet = Global.get("$$objFldGet");
    static final Object $$objFldSet = Global.get("$$objFldSet");
    static final Object $$proxyGet = Global.get("$$proxyGet");
    static final Object $$proxySet = Global.get("$$proxySet");
    static final Object $$delegGet = Global.get("$$delegGet");
    static final Object $$delegSet = Global.get("$$delegSet");

    Scriptable xdcO;
    Session ses;
    Value.Obj om;

    boolean isROV;
    boolean isCFG;

    Proto.Obj pkgP;
    Value.Obj pkgV;

    ArrayList<Object> imports = new ArrayList<Object>();
    ArrayList<Object> loggables = new ArrayList<Object>();
    ArrayList<Object> mcfgs = new ArrayList<Object>();
    ArrayList<Object> icfgs = new ArrayList<Object>();
    ArrayList<String> inherits = new ArrayList<String>();
    ArrayList<Object> proxies = new ArrayList<Object>();
    ArrayList<Object> sizes = new ArrayList<Object>();
    ArrayList<Object> tdefs = new ArrayList<Object>();

    void $$IMPORTS()
    {
        Global.callFxn("loadPackage", xdcO, "xdc");
        Global.callFxn("loadPackage", xdcO, "xdc.corevers");
        Global.callFxn("loadPackage", xdcO, "xdc.runtime");
    }

    void $$OBJECTS()
    {
        pkgP = (Proto.Obj)om.bind("ti.instrumentation.wdtimer.Package", new Proto.Obj());
        pkgV = (Value.Obj)om.bind("ti.instrumentation.wdtimer", new Value.Obj("ti.instrumentation.wdtimer", pkgP));
    }

    void Settings$$OBJECTS()
    {
        Proto.Obj po, spo;
        Value.Obj vo;

        po = (Proto.Obj)om.bind("ti.instrumentation.wdtimer.Settings.Module", new Proto.Obj());
        vo = (Value.Obj)om.bind("ti.instrumentation.wdtimer.Settings", new Value.Obj("ti.instrumentation.wdtimer.Settings", po));
        pkgV.bind("Settings", vo);
        // decls 
    }

    void WatchdogTimer$$OBJECTS()
    {
        Proto.Obj po, spo;
        Value.Obj vo;

        po = (Proto.Obj)om.bind("ti.instrumentation.wdtimer.WatchdogTimer.Module", new Proto.Obj());
        vo = (Value.Obj)om.bind("ti.instrumentation.wdtimer.WatchdogTimer", new Value.Obj("ti.instrumentation.wdtimer.WatchdogTimer", po));
        pkgV.bind("WatchdogTimer", vo);
        // decls 
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstcfgResetType", new Proto.Enm("ti.instrumentation.wdtimer.WatchdogTimer.RstcfgResetType"));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode", new Proto.Enm("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode"));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay", new Proto.Enm("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay"));
        spo = (Proto.Obj)om.bind("ti.instrumentation.wdtimer.WatchdogTimer$$InitCfg", new Proto.Obj());
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.InitCfg", new Proto.Str(spo, false));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.Status", new Proto.Enm("ti.instrumentation.wdtimer.WatchdogTimer.Status"));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.wdStates", new Proto.Enm("ti.instrumentation.wdtimer.WatchdogTimer.wdStates"));
        spo = (Proto.Obj)om.bind("ti.instrumentation.wdtimer.WatchdogTimer$$regOverlay", new Proto.Obj());
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.regOverlay", new Proto.Str(spo, false));
        spo = (Proto.Obj)om.bind("ti.instrumentation.wdtimer.WatchdogTimer$$Module_State", new Proto.Obj());
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.Module_State", new Proto.Str(spo, false));
    }

    void Settings$$CONSTS()
    {
        // module Settings
    }

    void WatchdogTimer$$CONSTS()
    {
        // module WatchdogTimer
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstcfgResetType_HARD_RESET", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstcfgResetType", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstcfgResetType_HARD_RESET", xdc.services.intern.xsr.Enum.intValue(0L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstcfgResetType_SOFT_RESET", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstcfgResetType", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstcfgResetType_SOFT_RESET", xdc.services.intern.xsr.Enum.intValue(1L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_DEFAULT_NO_OUTPUT_EVENT", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_DEFAULT_NO_OUTPUT_EVENT", xdc.services.intern.xsr.Enum.intValue(0L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_LOCAL_RESET_INPUT", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_LOCAL_RESET_INPUT", xdc.services.intern.xsr.Enum.intValue(2L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_NMI_INPUT", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_NMI_INPUT", xdc.services.intern.xsr.Enum.intValue(3L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_NMI_INPUT_PLUS_LOCAL_RESET_INPUT", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_NMI_INPUT_PLUS_LOCAL_RESET_INPUT", xdc.services.intern.xsr.Enum.intValue(4L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_DEVICE_RESET", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_DEVICE_RESET", xdc.services.intern.xsr.Enum.intValue(5L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_256CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_256CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.intValue(0L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_512CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_512CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.intValue(1L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_1024CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_1024CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.intValue(2L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_2048CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_2048CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.intValue(3L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_4096CPU_DIV_6_CYCLES_DEFAULT", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_4096CPU_DIV_6_CYCLES_DEFAULT", xdc.services.intern.xsr.Enum.intValue(4L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_8192CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_8192CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.intValue(5L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_16384CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_16384CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.intValue(6L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_32768CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_32768CPU_DIV_6_CYCLES", xdc.services.intern.xsr.Enum.intValue(7L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.Status_OKAY", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Status", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.Status_OKAY", xdc.services.intern.xsr.Enum.intValue(0L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.Status_ERROR_INVALID_RSTCFG_VAL", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Status", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.Status_ERROR_INVALID_RSTCFG_VAL", xdc.services.intern.xsr.Enum.intValue(1L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.Status_ERROR_ALREADY_IN_ACTIVE_STATE", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Status", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.Status_ERROR_ALREADY_IN_ACTIVE_STATE", xdc.services.intern.xsr.Enum.intValue(2L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.Status_ERROR_ALREADY_IN_SERVICE_STATE", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Status", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.Status_ERROR_ALREADY_IN_SERVICE_STATE", xdc.services.intern.xsr.Enum.intValue(3L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RSTCTRL_KEY_MASK", 0x0000FFFFL);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RSTCTRL_KEY_SHIFT", 0x00000000L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RSTCTRL_KEY_VALUE", 0x00005A69L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RSTCFG_WDTYPE_MASK", 0x00000001L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RSTMUXn_OMODE_MASK", 0x00000007L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RSTMUXn_OMODE_SHIFT", 1L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RSTMUXn_DELAY_MASK", 0x00000007L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.RSTMUXn_DELAY_SHIFT", 5L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.INTCTRLSTAT_PRDINTEN_MASK", 0x00000001L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.INTCTRLSTAT_PRDINTEN_LO_SHIFT", 0L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.INTCTRLSTAT_PRDINTEN_HI_SHIFT", 16L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.INTCTRLSTAT_PRDINTEN_ENABLE_INT", 1L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.TGCR_TIMLORS_MASK", 0x00000001L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.TGCR_TIMLORS_SHIFT", 0L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.TGCR_TIMLORS_NOT_IN_RESET", 1L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.TGCR_TIMHIRS_MASK", 0x00000001L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.TGCR_TIMHIRS_SHIFT", 1L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.TGCR_TIMHIRS_NOT_IN_RESET", 1L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.TGCR_TIMMODE_MASK", 0x00000003L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.TGCR_TIMMODE_SHIFT", 2L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.TGCR_TIMMODE_64BIT_WD_MODE", 0x2L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.TCR_ENAMODE_LO_MASK", 0x00000003L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.TCR_ENAMODE_LO_SHIFT", 6L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.TCR_ENAMODE_LO_CONTINUOUS_INC", 0x2L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.WDTCR_WDEN_MASK", 0x00000001L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.WDTCR_WDEN_SHIFT", 14L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.WDTCR_WATCHDOG_ENABLE", 1L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.WDTCR_WDFLAG_MASK", 0x00000001L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.WDTCR_WDFLAG_SHIFT", 15L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.WDTCR_WDKEY_MASK", 0x0000FFFFL);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.WDTCR_WDKEY_SHIFT", 16L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.WDTCR_WDKEY_KEY1", 0xA5C6L);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.WDTCR_WDKEY_KEY2", 0xDA7EL);
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.wdStates_INITIAL", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.wdStates", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.wdStates_INITIAL", xdc.services.intern.xsr.Enum.intValue(0L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.wdStates_PRE_ACTIVE", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.wdStates", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.wdStates_PRE_ACTIVE", xdc.services.intern.xsr.Enum.intValue(1L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.wdStates_ACTIVE", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.wdStates", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.wdStates_ACTIVE", xdc.services.intern.xsr.Enum.intValue(2L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.wdStates_SERVICE", xdc.services.intern.xsr.Enum.make((Proto.Enm)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.wdStates", "ti.instrumentation.wdtimer"), "ti.instrumentation.wdtimer.WatchdogTimer.wdStates_SERVICE", xdc.services.intern.xsr.Enum.intValue(3L)+0));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.Init", new Extern("ti_instrumentation_wdtimer_WatchdogTimer_Init__E", "ti_instrumentation_wdtimer_WatchdogTimer_Status(*)(ti_instrumentation_wdtimer_WatchdogTimer_InitCfg*)", true, false));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.ResetTimer", new Extern("ti_instrumentation_wdtimer_WatchdogTimer_ResetTimer__E", "ti_instrumentation_wdtimer_WatchdogTimer_Status(*)(xdc_Void)", true, false));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.MoveToServiceState", new Extern("ti_instrumentation_wdtimer_WatchdogTimer_MoveToServiceState__E", "ti_instrumentation_wdtimer_WatchdogTimer_Status(*)(xdc_Void)", true, false));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.MoveToActiveState", new Extern("ti_instrumentation_wdtimer_WatchdogTimer_MoveToActiveState__E", "ti_instrumentation_wdtimer_WatchdogTimer_Status(*)(xdc_Void)", true, false));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.ForceTimeout", new Extern("ti_instrumentation_wdtimer_WatchdogTimer_ForceTimeout__E", "xdc_Void(*)(xdc_Void)", true, false));
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer.HasTimeoutOccurred", new Extern("ti_instrumentation_wdtimer_WatchdogTimer_HasTimeoutOccurred__E", "xdc_Bool(*)(xdc_Void)", true, false));
    }

    void Settings$$CREATES()
    {
        Proto.Fxn fxn;
        StringBuilder sb;

    }

    void WatchdogTimer$$CREATES()
    {
        Proto.Fxn fxn;
        StringBuilder sb;

    }

    void Settings$$FUNCTIONS()
    {
        Proto.Fxn fxn;

    }

    void WatchdogTimer$$FUNCTIONS()
    {
        Proto.Fxn fxn;

    }

    void Settings$$SIZES()
    {
        Proto.Str so;
        Object fxn;

    }

    void WatchdogTimer$$SIZES()
    {
        Proto.Str so;
        Object fxn;

        so = (Proto.Str)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.InitCfg", "ti.instrumentation.wdtimer");
        sizes.clear();
        sizes.add(Global.newArray("wdPeriodLo", "UInt32"));
        sizes.add(Global.newArray("wdPeriodHi", "UInt32"));
        sizes.add(Global.newArray("wdResetType", "Nti.instrumentation.wdtimer.WatchdogTimer.RstcfgResetType;;0;1"));
        sizes.add(Global.newArray("wdRegisterTimeoutExc", "UShort"));
        sizes.add(Global.newArray("rstOmode", "Nti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode;;0;2;3;4;5"));
        sizes.add(Global.newArray("rstDelay", "Nti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay;;0;1;2;3;4;5;6;7"));
        so.bind("$$sizes", Global.newArray(sizes.toArray()));
        fxn = Global.eval("function() { return $$sizeof(xdc.om['ti.instrumentation.wdtimer.WatchdogTimer.InitCfg']); }");
        so.bind("$sizeof", fxn);
        fxn = Global.eval("function() { return $$alignof(xdc.om['ti.instrumentation.wdtimer.WatchdogTimer.InitCfg']); }");
        so.bind("$alignof", fxn);
        fxn = Global.eval("function(fld) { return $$offsetof(xdc.om['ti.instrumentation.wdtimer.WatchdogTimer.InitCfg'], fld); }");
        so.bind("$offsetof", fxn);
        so = (Proto.Str)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.regOverlay", "ti.instrumentation.wdtimer");
        sizes.clear();
        sizes.add(Global.newArray("RESERVED1", "UInt32"));
        sizes.add(Global.newArray("EMUMGT_CLKSPD", "UInt32"));
        sizes.add(Global.newArray("RESERVED2", "UInt32"));
        sizes.add(Global.newArray("RESERVED3", "UInt32"));
        sizes.add(Global.newArray("CNTLO", "UInt32"));
        sizes.add(Global.newArray("CNTHI", "UInt32"));
        sizes.add(Global.newArray("PRDLO", "UInt32"));
        sizes.add(Global.newArray("PRDHI", "UInt32"));
        sizes.add(Global.newArray("TCR", "UInt32"));
        sizes.add(Global.newArray("TGCR", "UInt32"));
        sizes.add(Global.newArray("WDTCR", "UInt32"));
        sizes.add(Global.newArray("RESERVED4", "UInt32"));
        sizes.add(Global.newArray("RESERVED5", "UInt32"));
        sizes.add(Global.newArray("RELLO", "UInt32"));
        sizes.add(Global.newArray("RELHI", "UInt32"));
        sizes.add(Global.newArray("CAPLO", "UInt32"));
        sizes.add(Global.newArray("CAPHI", "UInt32"));
        sizes.add(Global.newArray("INTCTLSTAT", "UInt32"));
        so.bind("$$sizes", Global.newArray(sizes.toArray()));
        fxn = Global.eval("function() { return $$sizeof(xdc.om['ti.instrumentation.wdtimer.WatchdogTimer.regOverlay']); }");
        so.bind("$sizeof", fxn);
        fxn = Global.eval("function() { return $$alignof(xdc.om['ti.instrumentation.wdtimer.WatchdogTimer.regOverlay']); }");
        so.bind("$alignof", fxn);
        fxn = Global.eval("function(fld) { return $$offsetof(xdc.om['ti.instrumentation.wdtimer.WatchdogTimer.regOverlay'], fld); }");
        so.bind("$offsetof", fxn);
        so = (Proto.Str)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Module_State", "ti.instrumentation.wdtimer");
        sizes.clear();
        sizes.add(Global.newArray("wdTimerState", "Nti.instrumentation.wdtimer.WatchdogTimer.wdStates;;0;1;2;3"));
        so.bind("$$sizes", Global.newArray(sizes.toArray()));
        fxn = Global.eval("function() { return $$sizeof(xdc.om['ti.instrumentation.wdtimer.WatchdogTimer.Module_State']); }");
        so.bind("$sizeof", fxn);
        fxn = Global.eval("function() { return $$alignof(xdc.om['ti.instrumentation.wdtimer.WatchdogTimer.Module_State']); }");
        so.bind("$alignof", fxn);
        fxn = Global.eval("function(fld) { return $$offsetof(xdc.om['ti.instrumentation.wdtimer.WatchdogTimer.Module_State'], fld); }");
        so.bind("$offsetof", fxn);
    }

    void Settings$$TYPES()
    {
        Scriptable cap;
        Proto.Obj po;
        Proto.Str ps;
        Proto.Typedef pt;
        Object fxn;

        po = (Proto.Obj)om.findStrict("ti.instrumentation.wdtimer.Settings.Module", "ti.instrumentation.wdtimer");
        po.init("ti.instrumentation.wdtimer.Settings.Module", om.findStrict("xdc.runtime.IModule.Module", "ti.instrumentation.wdtimer"));
                po.addFld("$hostonly", $$T_Num, 0, "r");
        if (isCFG) {
            po.addFld("WatchdogTimerVersionString", $$T_Str, "01.00.00.03", "w");
            po.addFld("deviceType", $$T_Str, "", "wh");
        }//isCFG
    }

    void WatchdogTimer$$TYPES()
    {
        Scriptable cap;
        Proto.Obj po;
        Proto.Str ps;
        Proto.Typedef pt;
        Object fxn;

        cap = (Scriptable)Global.callFxn("loadCapsule", xdcO, "ti/instrumentation/wdtimer/WatchdogTimer.xs");
        om.bind("ti.instrumentation.wdtimer.WatchdogTimer$$capsule", cap);
        po = (Proto.Obj)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Module", "ti.instrumentation.wdtimer");
        po.init("ti.instrumentation.wdtimer.WatchdogTimer.Module", om.findStrict("xdc.runtime.IModule.Module", "ti.instrumentation.wdtimer"));
                po.addFld("$hostonly", $$T_Num, 0, "r");
                po.addFld("RSTCTRL_KEY_MASK", Proto.Elm.newCNum("(xdc_Bits32)"), 0x0000FFFFL, "rh");
                po.addFld("RSTCTRL_KEY_SHIFT", Proto.Elm.newCNum("(xdc_Bits32)"), 0x00000000L, "rh");
                po.addFld("RSTCTRL_KEY_VALUE", Proto.Elm.newCNum("(xdc_Bits32)"), 0x00005A69L, "rh");
                po.addFld("RSTCFG_WDTYPE_MASK", Proto.Elm.newCNum("(xdc_Bits32)"), 0x00000001L, "rh");
                po.addFld("RSTMUXn_OMODE_MASK", Proto.Elm.newCNum("(xdc_Bits32)"), 0x00000007L, "rh");
                po.addFld("RSTMUXn_OMODE_SHIFT", Proto.Elm.newCNum("(xdc_Bits32)"), 1L, "rh");
                po.addFld("RSTMUXn_DELAY_MASK", Proto.Elm.newCNum("(xdc_Bits32)"), 0x00000007L, "rh");
                po.addFld("RSTMUXn_DELAY_SHIFT", Proto.Elm.newCNum("(xdc_Bits32)"), 5L, "rh");
                po.addFld("INTCTRLSTAT_PRDINTEN_MASK", Proto.Elm.newCNum("(xdc_Bits32)"), 0x00000001L, "rh");
                po.addFld("INTCTRLSTAT_PRDINTEN_LO_SHIFT", Proto.Elm.newCNum("(xdc_Bits32)"), 0L, "rh");
                po.addFld("INTCTRLSTAT_PRDINTEN_HI_SHIFT", Proto.Elm.newCNum("(xdc_Bits32)"), 16L, "rh");
                po.addFld("INTCTRLSTAT_PRDINTEN_ENABLE_INT", Proto.Elm.newCNum("(xdc_Bits32)"), 1L, "rh");
                po.addFld("TGCR_TIMLORS_MASK", Proto.Elm.newCNum("(xdc_Bits32)"), 0x00000001L, "rh");
                po.addFld("TGCR_TIMLORS_SHIFT", Proto.Elm.newCNum("(xdc_Bits32)"), 0L, "rh");
                po.addFld("TGCR_TIMLORS_NOT_IN_RESET", Proto.Elm.newCNum("(xdc_Bits32)"), 1L, "rh");
                po.addFld("TGCR_TIMHIRS_MASK", Proto.Elm.newCNum("(xdc_Bits32)"), 0x00000001L, "rh");
                po.addFld("TGCR_TIMHIRS_SHIFT", Proto.Elm.newCNum("(xdc_Bits32)"), 1L, "rh");
                po.addFld("TGCR_TIMHIRS_NOT_IN_RESET", Proto.Elm.newCNum("(xdc_Bits32)"), 1L, "rh");
                po.addFld("TGCR_TIMMODE_MASK", Proto.Elm.newCNum("(xdc_Bits32)"), 0x00000003L, "rh");
                po.addFld("TGCR_TIMMODE_SHIFT", Proto.Elm.newCNum("(xdc_Bits32)"), 2L, "rh");
                po.addFld("TGCR_TIMMODE_64BIT_WD_MODE", Proto.Elm.newCNum("(xdc_Bits32)"), 0x2L, "rh");
                po.addFld("TCR_ENAMODE_LO_MASK", Proto.Elm.newCNum("(xdc_Bits32)"), 0x00000003L, "rh");
                po.addFld("TCR_ENAMODE_LO_SHIFT", Proto.Elm.newCNum("(xdc_Bits32)"), 6L, "rh");
                po.addFld("TCR_ENAMODE_LO_CONTINUOUS_INC", Proto.Elm.newCNum("(xdc_Bits32)"), 0x2L, "rh");
                po.addFld("WDTCR_WDEN_MASK", Proto.Elm.newCNum("(xdc_Bits32)"), 0x00000001L, "rh");
                po.addFld("WDTCR_WDEN_SHIFT", Proto.Elm.newCNum("(xdc_Bits32)"), 14L, "rh");
                po.addFld("WDTCR_WATCHDOG_ENABLE", Proto.Elm.newCNum("(xdc_Bits32)"), 1L, "rh");
                po.addFld("WDTCR_WDFLAG_MASK", Proto.Elm.newCNum("(xdc_Bits32)"), 0x00000001L, "rh");
                po.addFld("WDTCR_WDFLAG_SHIFT", Proto.Elm.newCNum("(xdc_Bits32)"), 15L, "rh");
                po.addFld("WDTCR_WDKEY_MASK", Proto.Elm.newCNum("(xdc_Bits32)"), 0x0000FFFFL, "rh");
                po.addFld("WDTCR_WDKEY_SHIFT", Proto.Elm.newCNum("(xdc_Bits32)"), 16L, "rh");
                po.addFld("WDTCR_WDKEY_KEY1", Proto.Elm.newCNum("(xdc_Bits32)"), 0xA5C6L, "rh");
                po.addFld("WDTCR_WDKEY_KEY2", Proto.Elm.newCNum("(xdc_Bits32)"), 0xDA7EL, "rh");
        if (isCFG) {
            po.addFld("biosReplacementTimer", Proto.Elm.newCNum("(xdc_UInt)"), 0L, "w");
            po.addFld("biosReplacementTimerOwner", Proto.Elm.newCNum("(xdc_UInt)"), 0L, "w");
            po.addFld("RSTCTRL", new Proto.Adr("xdc_Ptr", "Pv"), $$UNDEF, "w");
            po.addFld("RSTCFG", new Proto.Adr("xdc_Ptr", "Pv"), $$UNDEF, "w");
            po.addFld("RSTMUXnBASE", new Proto.Adr("xdc_Ptr", "Pv"), $$UNDEF, "w");
            po.addFld("TINTLDSPINT", Proto.Elm.newCNum("(xdc_UInt)"), $$UNDEF, "w");
        }//isCFG
        fxn = Global.get(cap, "module$use");
        if (fxn != null) om.bind("ti.instrumentation.wdtimer.WatchdogTimer$$module$use", true);
        if (fxn != null) po.addFxn("module$use", $$T_Met, fxn);
        fxn = Global.get(cap, "module$meta$init");
        if (fxn != null) om.bind("ti.instrumentation.wdtimer.WatchdogTimer$$module$meta$init", true);
        if (fxn != null) po.addFxn("module$meta$init", $$T_Met, fxn);
        fxn = Global.get(cap, "module$static$init");
        if (fxn != null) om.bind("ti.instrumentation.wdtimer.WatchdogTimer$$module$static$init", true);
        if (fxn != null) po.addFxn("module$static$init", $$T_Met, fxn);
        fxn = Global.get(cap, "module$validate");
        if (fxn != null) om.bind("ti.instrumentation.wdtimer.WatchdogTimer$$module$validate", true);
        if (fxn != null) po.addFxn("module$validate", $$T_Met, fxn);
        // struct WatchdogTimer.InitCfg
        po = (Proto.Obj)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer$$InitCfg", "ti.instrumentation.wdtimer");
        po.init("ti.instrumentation.wdtimer.WatchdogTimer.InitCfg", null);
                po.addFld("$hostonly", $$T_Num, 0, "r");
                po.addFld("wdPeriodLo", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("wdPeriodHi", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("wdResetType", (Proto)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstcfgResetType", "ti.instrumentation.wdtimer"), $$UNDEF, "w");
                po.addFld("wdRegisterTimeoutExc", $$T_Bool, $$UNDEF, "w");
                po.addFld("rstOmode", (Proto)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode", "ti.instrumentation.wdtimer"), $$UNDEF, "w");
                po.addFld("rstDelay", (Proto)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay", "ti.instrumentation.wdtimer"), $$UNDEF, "w");
        // struct WatchdogTimer.regOverlay
        po = (Proto.Obj)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer$$regOverlay", "ti.instrumentation.wdtimer");
        po.init("ti.instrumentation.wdtimer.WatchdogTimer.regOverlay", null);
                po.addFld("$hostonly", $$T_Num, 0, "r");
                po.addFld("RESERVED1", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("EMUMGT_CLKSPD", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("RESERVED2", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("RESERVED3", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("CNTLO", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("CNTHI", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("PRDLO", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("PRDHI", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("TCR", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("TGCR", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("WDTCR", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("RESERVED4", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("RESERVED5", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("RELLO", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("RELHI", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("CAPLO", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("CAPHI", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
                po.addFld("INTCTLSTAT", Proto.Elm.newCNum("(xdc_Bits32)"), $$UNDEF, "w");
        // struct WatchdogTimer.Module_State
        po = (Proto.Obj)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer$$Module_State", "ti.instrumentation.wdtimer");
        po.init("ti.instrumentation.wdtimer.WatchdogTimer.Module_State", null);
                po.addFld("$hostonly", $$T_Num, 0, "r");
                po.addFld("wdTimerState", (Proto)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.wdStates", "ti.instrumentation.wdtimer"), $$UNDEF, "w");
    }

    void Settings$$ROV()
    {
        Proto.Obj po;
        Value.Obj vo;

        vo = (Value.Obj)om.findStrict("ti.instrumentation.wdtimer.Settings", "ti.instrumentation.wdtimer");
    }

    void WatchdogTimer$$ROV()
    {
        Proto.Obj po;
        Value.Obj vo;

        vo = (Value.Obj)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer", "ti.instrumentation.wdtimer");
        vo.bind("InitCfg$fetchDesc", Global.newObject("type", "ti.instrumentation.wdtimer.WatchdogTimer.InitCfg", "isScalar", false));
        po = (Proto.Obj)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer$$InitCfg", "ti.instrumentation.wdtimer");
        vo.bind("regOverlay$fetchDesc", Global.newObject("type", "ti.instrumentation.wdtimer.WatchdogTimer.regOverlay", "isScalar", false));
        po = (Proto.Obj)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer$$regOverlay", "ti.instrumentation.wdtimer");
        vo.bind("Module_State$fetchDesc", Global.newObject("type", "ti.instrumentation.wdtimer.WatchdogTimer.Module_State", "isScalar", false));
        po = (Proto.Obj)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer$$Module_State", "ti.instrumentation.wdtimer");
    }

    void $$SINGLETONS()
    {
        pkgP.init("ti.instrumentation.wdtimer.Package", (Proto.Obj)om.findStrict("xdc.IPackage.Module", "ti.instrumentation.wdtimer"));
        Scriptable cap = (Scriptable)Global.callFxn("loadCapsule", xdcO, "ti/instrumentation/wdtimer/package.xs");
        om.bind("xdc.IPackage$$capsule", cap);
        Object fxn;
                fxn = Global.get(cap, "init");
                if (fxn != null) pkgP.addFxn("init", (Proto.Fxn)om.findStrict("xdc.IPackage$$init", "ti.instrumentation.wdtimer"), fxn);
                fxn = Global.get(cap, "close");
                if (fxn != null) pkgP.addFxn("close", (Proto.Fxn)om.findStrict("xdc.IPackage$$close", "ti.instrumentation.wdtimer"), fxn);
                fxn = Global.get(cap, "validate");
                if (fxn != null) pkgP.addFxn("validate", (Proto.Fxn)om.findStrict("xdc.IPackage$$validate", "ti.instrumentation.wdtimer"), fxn);
                fxn = Global.get(cap, "exit");
                if (fxn != null) pkgP.addFxn("exit", (Proto.Fxn)om.findStrict("xdc.IPackage$$exit", "ti.instrumentation.wdtimer"), fxn);
                fxn = Global.get(cap, "getLibs");
                if (fxn != null) pkgP.addFxn("getLibs", (Proto.Fxn)om.findStrict("xdc.IPackage$$getLibs", "ti.instrumentation.wdtimer"), fxn);
                fxn = Global.get(cap, "getSects");
                if (fxn != null) pkgP.addFxn("getSects", (Proto.Fxn)om.findStrict("xdc.IPackage$$getSects", "ti.instrumentation.wdtimer"), fxn);
        pkgP.bind("$capsule", cap);
        pkgV.init2(pkgP, "ti.instrumentation.wdtimer", Value.DEFAULT, false);
        pkgV.bind("$name", "ti.instrumentation.wdtimer");
        pkgV.bind("$category", "Package");
        pkgV.bind("$$qn", "ti.instrumentation.wdtimer.");
        pkgV.bind("$vers", Global.newArray(1, 0, 0, 3));
        Value.Map atmap = (Value.Map)pkgV.getv("$attr");
        atmap.seal("length");
        imports.clear();
        pkgV.bind("$imports", imports);
        StringBuilder sb = new StringBuilder();
        sb.append("var pkg = xdc.om['ti.instrumentation.wdtimer'];\n");
        sb.append("if (pkg.$vers.length >= 3) {\n");
            sb.append("pkg.$vers.push(Packages.xdc.services.global.Vers.getDate(xdc.csd() + '/..'));\n");
        sb.append("}\n");
        sb.append("if ('ti.instrumentation.wdtimer$$stat$base' in xdc.om) {\n");
            sb.append("pkg.packageBase = xdc.om['ti.instrumentation.wdtimer$$stat$base'];\n");
            sb.append("pkg.packageRepository = xdc.om['ti.instrumentation.wdtimer$$stat$root'];\n");
        sb.append("}\n");
        sb.append("pkg.build.libraries = [\n");
        sb.append("];\n");
        sb.append("pkg.build.libDesc = [\n");
        sb.append("];\n");
        Global.eval(sb.toString());
    }

    void Settings$$SINGLETONS()
    {
        Proto.Obj po;
        Value.Obj vo;

        vo = (Value.Obj)om.findStrict("ti.instrumentation.wdtimer.Settings", "ti.instrumentation.wdtimer");
        po = (Proto.Obj)om.findStrict("ti.instrumentation.wdtimer.Settings.Module", "ti.instrumentation.wdtimer");
        vo.init2(po, "ti.instrumentation.wdtimer.Settings", $$DEFAULT, false);
        vo.bind("Module", po);
        vo.bind("$category", "Module");
        vo.bind("$capsule", $$UNDEF);
        vo.bind("$package", om.findStrict("ti.instrumentation.wdtimer", "ti.instrumentation.wdtimer"));
        tdefs.clear();
        proxies.clear();
        mcfgs.clear();
        icfgs.clear();
        inherits.clear();
        mcfgs.add("Module__diagsEnabled");
        icfgs.add("Module__diagsEnabled");
        mcfgs.add("Module__diagsIncluded");
        icfgs.add("Module__diagsIncluded");
        mcfgs.add("Module__diagsMask");
        icfgs.add("Module__diagsMask");
        mcfgs.add("Module__gateObj");
        icfgs.add("Module__gateObj");
        mcfgs.add("Module__gatePrms");
        icfgs.add("Module__gatePrms");
        mcfgs.add("Module__id");
        icfgs.add("Module__id");
        mcfgs.add("Module__loggerDefined");
        icfgs.add("Module__loggerDefined");
        mcfgs.add("Module__loggerObj");
        icfgs.add("Module__loggerObj");
        mcfgs.add("Module__loggerFxn0");
        icfgs.add("Module__loggerFxn0");
        mcfgs.add("Module__loggerFxn1");
        icfgs.add("Module__loggerFxn1");
        mcfgs.add("Module__loggerFxn2");
        icfgs.add("Module__loggerFxn2");
        mcfgs.add("Module__loggerFxn4");
        icfgs.add("Module__loggerFxn4");
        mcfgs.add("Module__loggerFxn8");
        icfgs.add("Module__loggerFxn8");
        mcfgs.add("Module__startupDoneFxn");
        icfgs.add("Module__startupDoneFxn");
        mcfgs.add("Object__count");
        icfgs.add("Object__count");
        mcfgs.add("Object__heap");
        icfgs.add("Object__heap");
        mcfgs.add("Object__sizeof");
        icfgs.add("Object__sizeof");
        mcfgs.add("Object__table");
        icfgs.add("Object__table");
        mcfgs.add("WatchdogTimerVersionString");
        vo.bind("$$tdefs", Global.newArray(tdefs.toArray()));
        vo.bind("$$proxies", Global.newArray(proxies.toArray()));
        vo.bind("$$mcfgs", Global.newArray(mcfgs.toArray()));
        vo.bind("$$icfgs", Global.newArray(icfgs.toArray()));
        inherits.add("xdc.runtime");
        vo.bind("$$inherits", Global.newArray(inherits.toArray()));
        ((Value.Arr)pkgV.getv("$modules")).add(vo);
        ((Value.Arr)om.findStrict("$modules", "ti.instrumentation.wdtimer")).add(vo);
        vo.bind("$$instflag", 0);
        vo.bind("$$iobjflag", 0);
        vo.bind("$$sizeflag", 1);
        vo.bind("$$dlgflag", 0);
        vo.bind("$$iflag", 0);
        vo.bind("$$romcfgs", "|");
        vo.bind("$$nortsflag", 0);
        if (isCFG) {
            Proto.Str ps = (Proto.Str)vo.find("Module_State");
            if (ps != null) vo.bind("$object", ps.newInstance());
            vo.bind("$$meta_iobj", 1);
        }//isCFG
        vo.bind("$$fxntab", Global.newArray("ti_instrumentation_wdtimer_Settings_Module__startupDone__E"));
        vo.bind("$$logEvtCfgs", Global.newArray());
        vo.bind("$$errorDescCfgs", Global.newArray());
        vo.bind("$$assertDescCfgs", Global.newArray());
        Value.Map atmap = (Value.Map)vo.getv("$attr");
        atmap.seal("length");
        vo.bind("MODULE_STARTUP$", 0);
        vo.bind("PROXY$", 0);
        loggables.clear();
        vo.bind("$$loggables", loggables.toArray());
        pkgV.bind("Settings", vo);
        ((Value.Arr)pkgV.getv("$unitNames")).add("Settings");
    }

    void WatchdogTimer$$SINGLETONS()
    {
        Proto.Obj po;
        Value.Obj vo;

        vo = (Value.Obj)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer", "ti.instrumentation.wdtimer");
        po = (Proto.Obj)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Module", "ti.instrumentation.wdtimer");
        vo.init2(po, "ti.instrumentation.wdtimer.WatchdogTimer", $$DEFAULT, false);
        vo.bind("Module", po);
        vo.bind("$category", "Module");
        vo.bind("$capsule", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer$$capsule", "ti.instrumentation.wdtimer"));
        vo.bind("$package", om.findStrict("ti.instrumentation.wdtimer", "ti.instrumentation.wdtimer"));
        tdefs.clear();
        proxies.clear();
        mcfgs.clear();
        icfgs.clear();
        inherits.clear();
        mcfgs.add("Module__diagsEnabled");
        icfgs.add("Module__diagsEnabled");
        mcfgs.add("Module__diagsIncluded");
        icfgs.add("Module__diagsIncluded");
        mcfgs.add("Module__diagsMask");
        icfgs.add("Module__diagsMask");
        mcfgs.add("Module__gateObj");
        icfgs.add("Module__gateObj");
        mcfgs.add("Module__gatePrms");
        icfgs.add("Module__gatePrms");
        mcfgs.add("Module__id");
        icfgs.add("Module__id");
        mcfgs.add("Module__loggerDefined");
        icfgs.add("Module__loggerDefined");
        mcfgs.add("Module__loggerObj");
        icfgs.add("Module__loggerObj");
        mcfgs.add("Module__loggerFxn0");
        icfgs.add("Module__loggerFxn0");
        mcfgs.add("Module__loggerFxn1");
        icfgs.add("Module__loggerFxn1");
        mcfgs.add("Module__loggerFxn2");
        icfgs.add("Module__loggerFxn2");
        mcfgs.add("Module__loggerFxn4");
        icfgs.add("Module__loggerFxn4");
        mcfgs.add("Module__loggerFxn8");
        icfgs.add("Module__loggerFxn8");
        mcfgs.add("Module__startupDoneFxn");
        icfgs.add("Module__startupDoneFxn");
        mcfgs.add("Object__count");
        icfgs.add("Object__count");
        mcfgs.add("Object__heap");
        icfgs.add("Object__heap");
        mcfgs.add("Object__sizeof");
        icfgs.add("Object__sizeof");
        mcfgs.add("Object__table");
        icfgs.add("Object__table");
        vo.bind("RstcfgResetType", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstcfgResetType", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxOmode", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxDelay", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay", "ti.instrumentation.wdtimer"));
        vo.bind("InitCfg", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.InitCfg", "ti.instrumentation.wdtimer"));
        tdefs.add(om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.InitCfg", "ti.instrumentation.wdtimer"));
        vo.bind("Status", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Status", "ti.instrumentation.wdtimer"));
        mcfgs.add("biosReplacementTimer");
        mcfgs.add("biosReplacementTimerOwner");
        vo.bind("wdStates", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.wdStates", "ti.instrumentation.wdtimer"));
        vo.bind("regOverlay", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.regOverlay", "ti.instrumentation.wdtimer"));
        tdefs.add(om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.regOverlay", "ti.instrumentation.wdtimer"));
        mcfgs.add("RSTCTRL");
        icfgs.add("RSTCTRL");
        mcfgs.add("RSTCFG");
        icfgs.add("RSTCFG");
        mcfgs.add("RSTMUXnBASE");
        icfgs.add("RSTMUXnBASE");
        mcfgs.add("TINTLDSPINT");
        icfgs.add("TINTLDSPINT");
        vo.bind("Module_State", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Module_State", "ti.instrumentation.wdtimer"));
        tdefs.add(om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Module_State", "ti.instrumentation.wdtimer"));
        vo.bind("RstcfgResetType_HARD_RESET", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstcfgResetType_HARD_RESET", "ti.instrumentation.wdtimer"));
        vo.bind("RstcfgResetType_SOFT_RESET", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstcfgResetType_SOFT_RESET", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxOmode_DEFAULT_NO_OUTPUT_EVENT", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_DEFAULT_NO_OUTPUT_EVENT", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxOmode_LOCAL_RESET_INPUT", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_LOCAL_RESET_INPUT", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxOmode_NMI_INPUT", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_NMI_INPUT", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxOmode_NMI_INPUT_PLUS_LOCAL_RESET_INPUT", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_NMI_INPUT_PLUS_LOCAL_RESET_INPUT", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxOmode_DEVICE_RESET", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxOmode_DEVICE_RESET", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxDelay_256CPU_DIV_6_CYCLES", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_256CPU_DIV_6_CYCLES", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxDelay_512CPU_DIV_6_CYCLES", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_512CPU_DIV_6_CYCLES", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxDelay_1024CPU_DIV_6_CYCLES", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_1024CPU_DIV_6_CYCLES", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxDelay_2048CPU_DIV_6_CYCLES", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_2048CPU_DIV_6_CYCLES", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxDelay_4096CPU_DIV_6_CYCLES_DEFAULT", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_4096CPU_DIV_6_CYCLES_DEFAULT", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxDelay_8192CPU_DIV_6_CYCLES", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_8192CPU_DIV_6_CYCLES", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxDelay_16384CPU_DIV_6_CYCLES", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_16384CPU_DIV_6_CYCLES", "ti.instrumentation.wdtimer"));
        vo.bind("RstmuxDelay_32768CPU_DIV_6_CYCLES", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.RstmuxDelay_32768CPU_DIV_6_CYCLES", "ti.instrumentation.wdtimer"));
        vo.bind("Status_OKAY", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Status_OKAY", "ti.instrumentation.wdtimer"));
        vo.bind("Status_ERROR_INVALID_RSTCFG_VAL", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Status_ERROR_INVALID_RSTCFG_VAL", "ti.instrumentation.wdtimer"));
        vo.bind("Status_ERROR_ALREADY_IN_ACTIVE_STATE", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Status_ERROR_ALREADY_IN_ACTIVE_STATE", "ti.instrumentation.wdtimer"));
        vo.bind("Status_ERROR_ALREADY_IN_SERVICE_STATE", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Status_ERROR_ALREADY_IN_SERVICE_STATE", "ti.instrumentation.wdtimer"));
        vo.bind("wdStates_INITIAL", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.wdStates_INITIAL", "ti.instrumentation.wdtimer"));
        vo.bind("wdStates_PRE_ACTIVE", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.wdStates_PRE_ACTIVE", "ti.instrumentation.wdtimer"));
        vo.bind("wdStates_ACTIVE", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.wdStates_ACTIVE", "ti.instrumentation.wdtimer"));
        vo.bind("wdStates_SERVICE", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.wdStates_SERVICE", "ti.instrumentation.wdtimer"));
        vo.bind("$$tdefs", Global.newArray(tdefs.toArray()));
        vo.bind("$$proxies", Global.newArray(proxies.toArray()));
        vo.bind("$$mcfgs", Global.newArray(mcfgs.toArray()));
        vo.bind("$$icfgs", Global.newArray(icfgs.toArray()));
        inherits.add("xdc.runtime");
        vo.bind("$$inherits", Global.newArray(inherits.toArray()));
        ((Value.Arr)pkgV.getv("$modules")).add(vo);
        ((Value.Arr)om.findStrict("$modules", "ti.instrumentation.wdtimer")).add(vo);
        vo.bind("$$instflag", 0);
        vo.bind("$$iobjflag", 0);
        vo.bind("$$sizeflag", 1);
        vo.bind("$$dlgflag", 0);
        vo.bind("$$iflag", 0);
        vo.bind("$$romcfgs", "|");
        vo.bind("$$nortsflag", 0);
        if (isCFG) {
            Proto.Str ps = (Proto.Str)vo.find("Module_State");
            if (ps != null) vo.bind("$object", ps.newInstance());
            vo.bind("$$meta_iobj", 1);
        }//isCFG
        vo.bind("Init", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.Init", "ti.instrumentation.wdtimer"));
        vo.bind("ResetTimer", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.ResetTimer", "ti.instrumentation.wdtimer"));
        vo.bind("MoveToServiceState", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.MoveToServiceState", "ti.instrumentation.wdtimer"));
        vo.bind("MoveToActiveState", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.MoveToActiveState", "ti.instrumentation.wdtimer"));
        vo.bind("ForceTimeout", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.ForceTimeout", "ti.instrumentation.wdtimer"));
        vo.bind("HasTimeoutOccurred", om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer.HasTimeoutOccurred", "ti.instrumentation.wdtimer"));
        vo.bind("$$fxntab", Global.newArray("ti_instrumentation_wdtimer_WatchdogTimer_Module__startupDone__E", "ti_instrumentation_wdtimer_WatchdogTimer_Init__E", "ti_instrumentation_wdtimer_WatchdogTimer_ResetTimer__E", "ti_instrumentation_wdtimer_WatchdogTimer_MoveToServiceState__E", "ti_instrumentation_wdtimer_WatchdogTimer_MoveToActiveState__E", "ti_instrumentation_wdtimer_WatchdogTimer_ForceTimeout__E", "ti_instrumentation_wdtimer_WatchdogTimer_HasTimeoutOccurred__E"));
        vo.bind("$$logEvtCfgs", Global.newArray());
        vo.bind("$$errorDescCfgs", Global.newArray());
        vo.bind("$$assertDescCfgs", Global.newArray());
        Value.Map atmap = (Value.Map)vo.getv("$attr");
        atmap.seal("length");
        vo.bind("MODULE_STARTUP$", 0);
        vo.bind("PROXY$", 0);
        loggables.clear();
        vo.bind("$$loggables", loggables.toArray());
        pkgV.bind("WatchdogTimer", vo);
        ((Value.Arr)pkgV.getv("$unitNames")).add("WatchdogTimer");
    }

    void $$INITIALIZATION()
    {
        Value.Obj vo;

        if (isCFG) {
        }//isCFG
        Global.callFxn("module$meta$init", (Scriptable)om.findStrict("ti.instrumentation.wdtimer.Settings", "ti.instrumentation.wdtimer"));
        Global.callFxn("module$meta$init", (Scriptable)om.findStrict("ti.instrumentation.wdtimer.WatchdogTimer", "ti.instrumentation.wdtimer"));
        Global.callFxn("init", pkgV);
        ((Value.Obj)om.getv("ti.instrumentation.wdtimer.Settings")).bless();
        ((Value.Obj)om.getv("ti.instrumentation.wdtimer.WatchdogTimer")).bless();
        ((Value.Arr)om.findStrict("$packages", "ti.instrumentation.wdtimer")).add(pkgV);
    }

    public void exec( Scriptable xdcO, Session ses )
    {
        this.xdcO = xdcO;
        this.ses = ses;
        om = (Value.Obj)xdcO.get("om", null);

        Object o = om.geto("$name");
        String s = o instanceof String ? (String)o : null;
        isCFG = s != null && s.equals("cfg");
        isROV = s != null && s.equals("rov");

        $$IMPORTS();
        $$OBJECTS();
        Settings$$OBJECTS();
        WatchdogTimer$$OBJECTS();
        Settings$$CONSTS();
        WatchdogTimer$$CONSTS();
        Settings$$CREATES();
        WatchdogTimer$$CREATES();
        Settings$$FUNCTIONS();
        WatchdogTimer$$FUNCTIONS();
        Settings$$SIZES();
        WatchdogTimer$$SIZES();
        Settings$$TYPES();
        WatchdogTimer$$TYPES();
        if (isROV) {
            Settings$$ROV();
            WatchdogTimer$$ROV();
        }//isROV
        $$SINGLETONS();
        Settings$$SINGLETONS();
        WatchdogTimer$$SINGLETONS();
        $$INITIALIZATION();
    }
}
