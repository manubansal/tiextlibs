/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B21
 */

#ifndef ti_instrumentation_wdtimer__
#define ti_instrumentation_wdtimer__


/*
 * ======== module ti.instrumentation.wdtimer.Settings ========
 */


/*
 * ======== module ti.instrumentation.wdtimer.WatchdogTimer ========
 */

typedef struct ti_instrumentation_wdtimer_WatchdogTimer_InitCfg ti_instrumentation_wdtimer_WatchdogTimer_InitCfg;
typedef struct ti_instrumentation_wdtimer_WatchdogTimer_regOverlay ti_instrumentation_wdtimer_WatchdogTimer_regOverlay;
typedef struct ti_instrumentation_wdtimer_WatchdogTimer_Module_State ti_instrumentation_wdtimer_WatchdogTimer_Module_State;


#endif /* ti_instrumentation_wdtimer__ */ 
