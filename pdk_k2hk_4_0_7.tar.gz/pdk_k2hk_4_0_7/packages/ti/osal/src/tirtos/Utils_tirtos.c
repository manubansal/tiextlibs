/*
 * Copyright (c) 2015-2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/*
 *  ======== HwiP_tirtos.c ========
 */

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include <xdc/runtime/Assert.h>
#include <ti/osal/src/tirtos/tirtos_config.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>

/* External Clock should be defined under osal_soc.h
 * if SOC is not supporting it, set to -1
 */
#ifndef EXTERNAL_CLOCK_KHZ_DEFAULT
#define EXTERNAL_CLOCK_KHZ_DEFAULT (-(int32_t)(1))
#endif

#ifndef OSAL_DELAY_TIMER_ADDR_DEFAULT
#define OSAL_DELAY_TIMER_ADDR_DEFAULT ((uintptr_t)(NULL))
#endif

/* Global Osal_HwAttr structure */
Osal_HwAttrs  gOsal_HwAttrs = {
   EXTERNAL_CLOCK_KHZ_DEFAULT,
#ifdef _TMS320C6X
   /* ECM_intNum[]: Event combiner interrupts */ 
  { OSAL_ECM_GROUP0_INT, /* Interrupt[4-15] to use for Event Combiner Group 0 */
    OSAL_ECM_GROUP1_INT, /* Interrupt[4-15] to use for Event Combiner Group 1 */
    OSAL_ECM_GROUP2_INT, /* Interrupt[4-15] to use for Event Combiner Group 2 */
    OSAL_ECM_GROUP3_INT  /* Interrupt[4-15] to use for Event Combiner Group 3 */
  },
#endif
  OSAL_HWACCESS_UNRESTRICTED,
  /* Below timer base configuration is applicable for AM335x/AM437x SoCs */
  (uintptr_t) OSAL_DELAY_TIMER_ADDR_DEFAULT /* Timer Base address for osal delay implementation for AM3/AM4 parts */
};
/*
 *  ======== _DebugP_assert ========
 */
void _DebugP_assert(int32_t expression, const char *file, int32_t line); /*for misra warnings*/
void _DebugP_assert(int32_t expression, const char *file, int32_t line)
{
    if (expression) {
        xdc_runtime_Assert_raise__I(Module__MID, file, line, NULL);
    }
}

Osal_ThreadType Osal_getThreadType(void)
{
    Osal_ThreadType osalThreadType;
    BIOS_ThreadType biosThreadType = BIOS_getThreadType();

    switch (biosThreadType)
    {
    case BIOS_ThreadType_Hwi:
        osalThreadType = Osal_ThreadType_Hwi;
        break;
    case BIOS_ThreadType_Swi:
        osalThreadType = Osal_ThreadType_Swi;
        break;
    case BIOS_ThreadType_Task:
        osalThreadType = Osal_ThreadType_Task;
        break;
    case BIOS_ThreadType_Main:
        osalThreadType = Osal_ThreadType_Main;
        break;
    default:
        osalThreadType = Osal_ThreadType_Main;
        break;
    }
    return (osalThreadType);
}


/* Osal delay */
int32_t Osal_delay(uint32_t nTicks)
{
  Osal_ThreadType type;
  int32_t   ret;

  type = Osal_getThreadType();
  if (type == Osal_ThreadType_Task) {
    Task_sleep(nTicks);
    ret = osal_OK;
  }
  else {
    ret = osal_FAILURE;
  }
  return(ret);
}

/*
 * set Osal_HwAttrs structure
 */
int32_t Osal_setHwAttrs(uint32_t ctrlBitMap, const Osal_HwAttrs *hwAttrs)
{
   int32_t  ret = osal_FAILURE;
   if (hwAttrs != NULL) {

     if (ctrlBitMap & OSAL_HWATTR_SET_EXT_CLK) {
       gOsal_HwAttrs.extClkKHz= hwAttrs->extClkKHz;
     }

#ifdef _TMS320C6X
     /* Set the Event Combiner Interrupts */
     if (ctrlBitMap & OSAL_HWATTR_SET_ECM_INT) {
       memcpy(gOsal_HwAttrs.ECM_intNum,hwAttrs->ECM_intNum,4*sizeof(gOsal_HwAttrs.ECM_intNum[0]));
     }
#endif
     /* Set the Hw Access type */
     if (ctrlBitMap & OSAL_HWATTR_SET_HWACCESS_TYPE) {
       gOsal_HwAttrs.hwAccessType = hwAttrs->hwAccessType;
     }

     ret = osal_OK;
   }
   return(ret);
}

/*
 * get Osal_HwAttrs structure
 */
int32_t Osal_getHwAttrs( Osal_HwAttrs *hwAttrs)
{
   int32_t  ret = osal_FAILURE;
   if (hwAttrs != NULL) {
     memcpy(hwAttrs, &gOsal_HwAttrs, sizeof(Osal_HwAttrs));
     ret = osal_OK;
   }
   return(ret);
}
