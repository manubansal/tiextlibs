/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B21
 */

#ifndef ti_osal__
#define ti_osal__


/*
 * ======== module ti.osal.Settings ========
 */



#endif /* ti_osal__ */ 
