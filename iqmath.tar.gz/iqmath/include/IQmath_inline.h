/* ======================================================================== */
/* IQmath_inline.h : Contains inline version of all IQmath lib functions.   */
/* ======================================================================== */
/*            Copyright (c) 2007 Texas Instruments, Incorporated.           */
/*                           All Rights Reserved.                           */
/* ======================================================================== */

#ifndef __IQMATH_INLINE_H__
#define __IQMATH_INLINE_H__

#define _INLINE_IQMATH
#include "IQmath.h"


/*;;###########################################################################
;;
;; FILE:    FtoIQN.c
;;
;; TITLE:   C Callable IQ to Float Math Function
;;
;;===========================================================================
;; Function:   _FtoIQN
;;===========================================================================
;;
;; C Usage:    extern int _FtoIQ(float A);   // no round or sat
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = IEEE 754 floating-point equivalent of A
;; On Exit:    A4    = A in IQ format 
;;                       
;; Q range:    31 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  This operation converts an IEEE 754 Single-Precision 
;;             floating-point number to equivalent IQ number. This
;;             format is shown below:
;;
;;              31  30        23 22                                 0
;;             +-----------------------------------------------------+
;;             | s |      e     |                 f                  |
;;             +-----------------------------------------------------+
;;
;;             Value = (-1)^s * 2^(e-127) * 1.f
;;
;;             where: e = 1 to 254, f = 0.000000000 to ~1.0
;;                    e = 0, f = 0, s = 0, Value = 0.0
;;                    e = 0 and f != 0 case cannot occur in IQ math
;;                    e = 255 case cannot occur in IQ math
;;          
;;--------------------------------------------------------------------------*/



static inline I32_IQ _FtoIQN(float input, U32_IQ qfmt)
{
#ifdef _TMS320C6X

    U32_IQ al, x, temp1, temp2, sbits, e, imp=1;
    I32_IQ ah;
    x = _ftoi(input);     // Re-interprits the bits in float as an unsigned int
    temp2 = x & 0xc0000000u;        //stores the sign and hidden bit
    if(x == 0)
    {
        imp = 0;
    }

    /* ======================================================================== */
    /*  extract the exponent(sbits) & hidden bit                                */
    /* ======================================================================== */
    
    sbits = _extu(x, 1u, 24u);
    if(sbits < 128u)
    {
        temp2 = temp2 ^ 0x40000000u;
    }

    /* ======================================================================== */
    /*  find the no. of bits by which the final result has to be shiftehd        */
    /* ======================================================================== */
    
    e = 127u + (30u - qfmt);
    sbits = e - sbits;

    /* ======================================================================== */
    /*  arrange for representtion in Q-Format                                   */
    /* ======================================================================== */

    temp1 = x & 0x07fffffu;
    al = temp1;
    al = al << 7u;
    al = al | temp2;

    /* ======================================================================== */
    /*  if then sign is -ve complement the bits except sign bit                 */
    /* ======================================================================== */

    if(((temp2 >> 31u) != 0) && (temp1 != 0u))
    {
        al = al ^ 0x7fffff80u;
    }
    ah = (I32_IQ)al;
    ah =  ((I32_IQ)ah >> sbits);    //shift right by sbits
    ah = ah * (I32_IQ)imp;
    return(ah);

#else /* For host. (since no equivalent of _ftoIQ() exists */
    I32_IQ res;
    res = input * (1 << qfmt);
    return(res);
#endif /* _TMS320C6X */

}

/*###########################################################################
;;
;; FILE:    IQNabs.c
;;
;; TITLE:   C-Model: _IQNabs function
;;
;;===========================================================================
;; Function:   _IQNabs
;;===========================================================================
;;
;; C Usage:    extern long _IQabs(int A);  
;;
;;-------------------------------------------------------------------------
;;
;; On Entry:   A4    = A in IQ format
;; On Exit:    A4    = Absolute value of A in IQ format
;;                       
;; Q range:    31 to 1
;;
;;---------------------------------------------------------------------------*/




static inline I32_IQ _IQNabs(I32_IQ input)        
{   
    I32_IQ temp;
    temp = _abs(input);     
    return(temp);

}
/*###########################################################################
;;
;; FILE:    IQNacos.c
;;
;; TITLE:   C-Model: IQacos function
;;

;;===========================================================================
;; Function:   _IQNacos
;;===========================================================================
;;
;; C Usage:    extern long _IQNacos(long Rad);
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4 = Angle(radians)
;;
;; On Exit:    A4 = result in IQ format
;;
;; Q range:    29 to 1
;;
;;---------------------------------------------------------------------------
;; Notes:
;;   1) IQ format is limited to I31Q1 to I3Q29 inclusive.  Formats
;;      greater than Q29 are excluded since they would overflow return
;;      angles greater than 2 (e.g., y = pi).
;;
;;   2) This function uses the identity: acos(x) = pi/2 - asin(x).
;;      It simply calls IQasin(x), and then forms (pi/2 - IQasin(x))
;;
;;=========================================================================*/



static inline I32_IQ _IQNacos(I32_IQ in,U32_IQ qfmt)
{
/* ==================================================== */
/* Number of Taylor Series Terms                        */                              
/* ==================================================== */

#define TaylorSeriesOrder   0x05U                   
/* ==================================================== */
/* x value (0.5 in Q29 format)beyond which we apply     */
/* mapping transform to x                               */
/* ==================================================== */

#define xMax                0x10000000U         

/* ==================================================== */
/* PI/2 in Q29 format _IQ29(1.570796327)                */                              
/* ==================================================== */
#define pi2                 0x3243F6A8U         
//---------------------------------------------------------------


    U32_IQ LutIndex, i, x;
    U32_IQ  iTransform = 0;

    I64_IQ  reg64;
    U32_IQ offset, sign, y;

    I32_IQ  high, Dnorm, yn_new=0,out;
    I16_IQ  index_new;//, shift

    U32_IQ sbits;
    U32_IQ res, low,high_new,z_sbits;
    const U32_IQ k1 = 0x1DU, k3 =32u , k2 =29u;


    sign = (U32_IQ)in >> 31U;
    x = (U32_IQ)_abs(in);

    if(x > (1 << qfmt)) 
    {
        x = (1 << qfmt);
    }

    x <<= (k1 - qfmt);
    
    if( x > xMax)
    {
        iTransform = 1;
        y=(0x20000000U - x) >> 1;
        x = 0;
    }
        
    else 
    {
        y = 0;
    
    }   
//      y = _IQ29sqrt(y);
    /* ==================================================== */
    /* code for _IQ29sqrt(y) for enabling inlining          */
    /* ==================================================== */

    sbits = _norm((I32_IQ)y);
    high_new = y;
    Dnorm = (I32_IQ)(high_new << sbits);

    if(Dnorm > 0){
        index_new = (I16_IQ)(((U32_IQ)Dnorm) >> 23);
        index_new = (I16_IQ)(index_new - 127);
        yn_new = IQisqrtTable[index_new];
    }

    reg64 = _mpy32ll(yn_new, yn_new);
    high = (I32_IQ)_hill(reg64);
    low = 0;
    high_new = high;
    high = (I32_IQ)(high_new << 2);
    reg64 = _mpy32ll(Dnorm, high);
    high = (I32_IQ)_hill(reg64);

    high = 0x60000000 - high;   //1.5 - Yn*Yn*V/2
    reg64 = _mpy32ll(yn_new, high);
    high = (I32_IQ)_hill(reg64);
    high_new = high;
    high = (I32_IQ)(high_new << 2);

    yn_new = high;
    reg64 = _mpy32ll(yn_new, yn_new);
    high = (I32_IQ)_hill(reg64);
    high_new = high;
    high = (I32_IQ)(high_new << 2);
    reg64 = _mpy32ll(Dnorm, high);
    high = (I32_IQ)_hill(reg64);

    high = 0x60000000 - high;   //1.5 - Yn*Yn*V/2
    reg64 = _mpy32ll(yn_new, high);
    high = (I32_IQ)_hill(reg64);
    high_new = high;
    high = (I32_IQ)(high_new << 2);
    reg64 = _mpy32ll(Dnorm, high);
    high = (I32_IQ)_hill(reg64);

    z_sbits = (I32_IQ)(sbits << 31);

        if(z_sbits != 0)
        {
            reg64 = _mpy32ll(high, 0x2D413CCD);      // 1/sqrt(2)..IQsqrtRoundSatTable[7]
        }
        else
        {
            reg64 = _mpy32ll(high, 0x40000000);      // 1.0..IQsqrtRoundSatTable[5]
        }

    low = _loll(reg64);
    high = (I32_IQ)_hill(reg64);

    res = low >> 29;
        low <<= 3;
        high_new = high;
        high = (I32_IQ)(high_new << 3);
        high_new = high;
        high = (I32_IQ)(high_new | res);


    sbits >>= 1;
    high_new = high;
    res = (high_new << (k3 - sbits));
    low >>= sbits;
    high = (I32_IQ)(high_new >> sbits);
    low |= res;
  res = low >> 31;
  
   y = (U32_IQ)_sadd(high,(I32_IQ)res);

    /* ==================================================== */
    /* _IQ29sqrt(y) code ends here                          */                              
    /* ==================================================== */
    x = x + y;

    /* ==================================================== */
    /*_IQ29(0.015625) = 0x00800000                          */                              
    /* ==================================================== */

    LutIndex = ((x + 0x00800000U) >> 24) & 0x001FU;
    offset = TaylorSeriesOrder * LutIndex;
    yn_new = IQasinTable[offset];

    for(i = 0;i < 4;i++)
    {
        reg64 = _mpy32su(yn_new, x); 
        low = _loll(reg64) >> 29U;
        high_new = _hill(reg64) << 3;
        low += high_new;
        yn_new = (I32_IQ)low;
        offset++;
        yn_new += IQasinTable[offset];
    }

    if(iTransform == 1)
    {
        yn_new = (I32_IQ)(pi2 - ((U32_IQ)yn_new << 1));    
    }
    if(sign  == 1)
    {
        yn_new = -yn_new;
    }


    /* ======================================================= */
    /* y has inverse sine value.                               */
    /* out =pi/2 - y;                                          */
    /* ======================================================= */

    out = (I32_IQ)pi2 - yn_new;
    out = (I32_IQ)out >>  (k2 - qfmt);


    return out;





}







/*###########################################################################
;;
;; FILE:    IQNasin.c
;;
;; TITLE:   C-Model: _IQNasin function
;;
;;===========================================================================
;; Function:   _IQNasin
;;===========================================================================
;;
;; C Usage:    extern int _IQNasin(int X);   
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = X in IQ format
;;
;;
;; On Exit:    A4    = sqrt(X) result in IQ format
;;             A4    = 0 if input is -ve or 0
;;
;;                      Note: The square root of any number will never
;;                            overflow, hence saturation is not required.
;;
;; Q range:    29 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:
;;             1) The lookup table index into a 85 word asin table is calculated:
;;
;;                index = bits(28:24) of (x + half the interval)
;;                      = bits(28:24) of [x + (0.5/2^N)/2]
;;                      = bits(28:24) of [x + (0.5/2^4)/2]
;;                      = bits(28:24) of [x + 0.015625]
;;
;;             2) The output inverse sine value is calculated as follows:
;;
;;               f(x) = c4 * x^4 + c3 * x^3 + c2 * x^2 + c1 * x + c0
;;                where c4, c3, c2, c1, c0 are obtained from the table
;;
------------------------------------------------------------------------*/




static inline I32_IQ _IQNasin(I32_IQ in, U32_IQ qfmt)
{

/* ==================================================== */
/* Number of Taylor Series Terms                        */                              
/* ==================================================== */

#define TaylorSeriesOrder   0x05U                   
/* ==================================================== */
/* x value (0.5 in Q29 format)beyond which we apply     */
/* mapping transform to x                               */
/* ==================================================== */

#define xMax                0x10000000U         
/* ==================================================== */
/* PI/2 in Q29 format _IQ29(1.570796327)                */                              
/* ==================================================== */


#define pi2                 0x3243F6A8U     
//---------------------------------------------------------------

    U32_IQ LutIndex, i, x;
    U32_IQ  iTransform = 0;

    I64_IQ  reg64;
    U32_IQ offset, sign, y;

    I32_IQ  high, Dnorm, yn_new=0;
    I16_IQ  index_new;//, shift

    U32_IQ sbits;
    U32_IQ res, low,high_new,z_sbits;
    const U32_IQ k1 = 0x1DU, k3 =32u;



    sign = (U32_IQ)in >> 31U;
    x = (U32_IQ)_abs(in);

    if(x > (1 << qfmt)) 
    {
        x = (1 << qfmt);
    }

    x <<= (k1 - qfmt);
    
    if( x > xMax)
    {
        iTransform = 1;
        y=(0x20000000U - x) >> 1;
        x = 0;
    }
        
    else 
    {
        y = 0;
    
    }   

    /* ==================================================== */
    /* code for _IQ29sqrt(y) for enabling inlining          */
    /* ==================================================== */

    sbits = _norm((I32_IQ)y);
    high_new = y;
    Dnorm = (I32_IQ)(high_new << sbits);

    if(Dnorm > 0){
        index_new = (I16_IQ)(((U32_IQ)Dnorm) >> 23);
        index_new = (I16_IQ)(index_new - 127);
        yn_new = IQisqrtTable[index_new];
    }

    reg64 = _mpy32ll(yn_new, yn_new);
    high = (I32_IQ)_hill(reg64);
    low = 0;
    high_new = high;
    high = (I32_IQ)(high_new << 2);
    reg64 = _mpy32ll(Dnorm, high);
    high = (I32_IQ)_hill(reg64);

    high = 0x60000000 - high;   //1.5 - Yn*Yn*V/2
    reg64 = _mpy32ll(yn_new, high);
    high = (I32_IQ)_hill(reg64);
    high_new = high;
    high = (I32_IQ)(high_new << 2);

    yn_new = high;
    reg64 = _mpy32ll(yn_new, yn_new);
    high = (I32_IQ)_hill(reg64);
    high_new = high;
    high = (I32_IQ)(high_new << 2);
    reg64 = _mpy32ll(Dnorm, high);
    high = (I32_IQ)_hill(reg64);

    high = 0x60000000 - high;   //1.5 - Yn*Yn*V/2
    reg64 = _mpy32ll(yn_new, high);
    high = (I32_IQ)_hill(reg64);
    high_new = high;
    high = (I32_IQ)(high_new << 2);
    reg64 = _mpy32ll(Dnorm, high);
    high = (I32_IQ)_hill(reg64);

    z_sbits = (I32_IQ)(sbits << 31);

        if(z_sbits != 0)
        {
            reg64 = _mpy32ll(high, 0x2D413CCD);      // 1/sqrt(2)..IQsqrtRoundSatTable[7]
        }
        else
        {
            reg64 = _mpy32ll(high, 0x40000000);      // 1.0..IQsqrtRoundSatTable[5]
        }

    low = _loll(reg64);
    high = (I32_IQ)_hill(reg64);

    res = low >> 29;
        low <<= 3;
        high_new = high;
        high = (I32_IQ)(high_new << 3);
        high_new = high;
        high = (I32_IQ)(high_new | res);


    sbits >>= 1;
    high_new = high;
    res = (high_new << (k3 - sbits));
    low >>= sbits;
    high = (I32_IQ)(high_new >> sbits);
    low |= res;
  res = low >> 31;
  
   y = (U32_IQ)_sadd(high,(I32_IQ)res);

    /* ==================================================== */
    /* _IQ29sqrt(y) code ends here                          */                              
    /* ==================================================== */
    x = x + y;

    /* ==================================================== */
    /*_IQ29(0.015625) = 0x00800000                          */                              
    /* ==================================================== */

    LutIndex = ((x + 0x00800000U) >> 24) & 0x001FU;
    offset = TaylorSeriesOrder * LutIndex;
    yn_new = IQasinTable[offset];

    for(i = 0;i < 4;i++)
    {
        reg64 = _mpy32su(yn_new, x); 
        low = _loll(reg64) >> 29U;
        high_new = _hill(reg64) << 3;
        low += high_new;
        yn_new = (I32_IQ)low;
        offset++;
        yn_new += IQasinTable[offset];
    }

    if(iTransform == 1)
    {
        yn_new = (I32_IQ)(pi2 - ((U32_IQ)yn_new << 1));    
    }
    yn_new =((I32_IQ)yn_new >> (k1 - qfmt));
    if(sign  == 1)
    {
        yn_new = -yn_new;
    }
    return(yn_new);

} 









/*###########################################################################
;;
;; FILE:    IQNatan2.c
;;
;; TITLE:   C-Model: IQatan2 function
;;
;;===========================================================================
;; Function:   _IQNatan2
;;===========================================================================
;;
;; C Usage:    extern long _IQNatan2(long Y, long X);
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = Y in IQ format
;;             B4    = X in IQ format
;;
;;
;; On Exit:    A4    = Radian result in IQ format
;;                      if( X == 0.0 and Y == 0.0 ), ACC = 0.0
;;                      if( Y >= 0.0 ), 0.0 <= ACC <= PI
;;                      if( Y <  0.0 ), -PI < ACC < 0.0
;;
;; Q range:    29 to 1
;;
;;             Note: A value of Q30 is not feasible since the result would
;;                   saturate for angles greater then +/- 2.0 radians.
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The algorithm steps to calculate the "atan2" of the given 
;;             input X and Y is as follows:
;;
;;             Step(1):   if( abs(X) >= abs(Y) )
;;                            Numerator   = abs(Y)
;;                            Denominator = abs(X)
;;                        else
;;                            Numerator   = abs(X)
;;                            Denominator = abs(Y)
;;
;;             Step(2):   Ratio = Numerator/Denominator
;;
;;                        Note: Ratio range = 0.0 to 1.0
;;
;;             Step(3):   Use the upper 6-bits of the "Ratio" value as an
;;                        index into the table to obtain the coefficients
;;                        for a second order equation:
;;
;;                        _IQNatan2Table:
;;                             CoeffA0[0]
;;                             CoeffA1[0]
;;                             CoeffA2[0]
;;                                .
;;                                .
;;                             CoeffA0[63]
;;                             CoeffA1[63]
;;                             CoeffA2[63]
;;
;;             Step(4):   Calculate the angle using the folowing equation:
;;
;;                        arctan(Ratio) = A0 + A1*Ratio + A2*Ratio*Ratio
;;                        arctan(Ratio) = A0 + Ratio(A1 + A2*Ratio)
;;
;;             Step(5):   The final angle is determined as follows:
;;
;;                        if( X >= 0 and Y >= 0 and abs(X) >= abs(Y) )
;;                            Angle = arctan(abs(Y)/abs(X))
;;                        if( X >= 0 and Y >= 0 and abs(X) <  abs(Y) )
;;                            Angle = PI/2 - arctan(abs(X)/abs(Y))
;;                        if( X < 0  and Y >= 0 and abs(X) <  abs(Y) )
;;                            Angle = PI/2 + arctan(abs(X)/abs(Y))
;;                        if( X < 0  and Y >= 0 and abs(X) >= abs(Y) )
;;                            Angle = PI - arctan(abs(Y)/abs(X))
;;                        if( Y < 0 )
;;                            Angle = -Angle
;;
;;===========================================================================*/


         


static inline I32_IQ _IQNatan2(I32_IQ y, I32_IQ x,  U32_IQ qfmt)      
{


    I64_IQ res_64;
    I32_IQ num,den,ax,ay,Dnorm,Dm,output,output_neg,ratio,reg64_hi,reg64_los;
    U32_IQ res_lo,res_hi,res_1,res,sbits,reg64_lo,index_new;
    U32_IQ var2;
    U32_IQ mask,mbits,temp1;
    const U32_IQ k1 = 32U, k2 = 30U;


    /* ============================================================================= */
    /* Step(1):   if( abs(X) >= abs(Y) )                                             */
    /*                    Numerator   = abs(Y)                                       */
    /*                    Denominator = abs(X)                                       */
    /*                  else                                                         */
    /*                    Numerator   = abs(X)                                       */
    /*                    Denominator = abs(Y)                                       */
    /* ============================================================================= */

    ax=_abs(x);
    ay=_abs(y);


    num=ay;             //if (ax>ay)
    den=ax;             //if (ax>ay)


    if(ax<ay)
    {
        num=ax;         //num=_min32(ax,ay);
        den=ay;
    }

    /* ============================================================================= */
    /* Step(2):   Ratio = Numerator/Denominator                                      */
    /* Note: Ratio range = 0.0 to 1.0                                                */
    /* ============================================================================= */

    sbits=_norm(den);
    temp1 = den; 
    Dnorm= (I32_IQ) (temp1 << sbits);

    if(Dnorm==0)
    {
        index_new=0;
    }
    else
    {
        index_new=((U32_IQ)Dnorm)>>22;
        index_new=index_new-254U;
        index_new= index_new>>1;
    }

    Dm=IQdivTable[index_new];
    res_64=_mpy32ll(Dm,Dnorm);      // 32 * 32 BIT MULTIPLICATION 
    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* =============================================================== */
    /* shift left by 1  (res_64=res_64 << 1)                           */
    /* =============================================================== */

    res = res_lo >> (31);
    res_1 = (res_hi << 1);
    reg64_hi = (I32_IQ) ( res | res_1);


    reg64_hi=0x40000000-reg64_hi;           // (5) ACC   = 2.0 - Dm*Dnorm  (Q29)


    res_64=_mpy32ll(Dm,reg64_hi);           // ACC:P = Dm(2.0 - Dm*Dnorm)  (Q61)
    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* =============================================================== */
    /* shift left by 3 (res_64=res_64 << 3)                            */
    /* =============================================================== */

    res = res_lo >> (29);
    res_1 = (res_hi << 3);

    reg64_hi = (I32_IQ) (res | res_1);
    Dm=reg64_hi;

    res_64=_mpy32ll(Dm,Dnorm);
    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* =============================================================== */
    /* shift left by 1  (res_64=res_64 << 1)                           */
    /* =============================================================== */

    res = res_lo >> (31);
    res_1 = (res_hi << 1);
    reg64_hi = (I32_IQ) (res | res_1);

    reg64_hi=0x40000000-reg64_hi;           // (5) ACC   = 2.0 - Dm*Dnorm      (Q29)
    res_64=_mpy32ll(Dm,reg64_hi);           // ACC:P = Dm(2.0 - Dm*Dnorm)  (Q61)

    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* =============================================================== */
    /* shift left by 3 (res_64=res_64 << 3)                            */
    /* =============================================================== */

    res = res_lo >> (29);
    res_1 = (res_hi << 3);
    reg64_hi = (I32_IQ) (res | res_1);

    res_64=_mpy32ll(num,reg64_hi);


    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* Extract the 32 bit result from 64 bit. */
    res = res_lo >> (30);
    res_1 = (res_hi << 2);

    reg64_hi = (I32_IQ) (res | res_1);
    reg64_lo = res_lo << 2;


    var2 = (I16_IQ) (62U - qfmt - sbits);
    if(var2 >31)                                
    {
        var2= (I16_IQ) (var2-32U);
        ratio= (I32_IQ) reg64_hi>>var2;
    }
    else
    {
        mask= (U32_IQ)(((1)<<var2)-1);
        mbits=(I32_IQ) reg64_hi & mask;
        mbits=mbits<< (k1-var2);

        ratio= (I32_IQ)(reg64_lo>>var2);
        ratio= (I32_IQ)(mbits|(U32_IQ)ratio);  
    }


    /* ============================================================================= */
    /* Step(3):   Use the upper 6-bits of the "Ratio" value as an                    */
    /*            index into the table to obtain the coefficients                    */
    /*            for a second order equation                                        */
    /* ============================================================================= */

    res_64=_mpy32ll(ratio,64);          // ACC = int(64*Ratio)
    res_lo = _loll(res_64);
    res_hi = _hill(res_64);


    /* =============================================================== */
    /* shift left (res_64 << (32-qfmt))                            */
    /* =============================================================== */
    res = res_lo >> qfmt;
    res_1 = (res_hi << (k1-qfmt));
    reg64_hi = (I32_IQ) (res | res_1);

    index_new=((I32_IQ)reg64_hi&0xffff)*3;          // Index = 3 * int(64*Ratio)

    /* ============================================================================= */
    /* Step(4):   arctan(Ratio) = A0 + A1*Ratio + A2*Ratio*Ratio                     */
    /*            arctan(Ratio) = A0 + Ratio(A1 + A2*Ratio)                          */
    /* ============================================================================= */

    res_64=_mpy32ll(ratio,IQatan2Table[index_new+2U]);
    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* =============================================================== */
    /* shift left (res_64 << (32-qfmt))                                */
    /* =============================================================== */
    res = res_lo >> (qfmt);
    res_1 = (res_hi << (k1-qfmt));
    reg64_hi = (I32_IQ) (res | res_1);

    reg64_hi=reg64_hi+IQatan2Table[index_new+1];


    res_64=_mpy32ll(ratio,reg64_hi);
    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* =============================================================== */
    /* shift left (res_64 << (32-qfmt))                                */
    /* =============================================================== */

    res = res_lo >> (qfmt);
    res_1 = (res_hi << (k1-qfmt));
    reg64_hi = (I32_IQ) (res | res_1);

    reg64_hi=reg64_hi+IQatan2Table[index_new];          // ACC   = A0 + Ratio(A1 + A2*Ratio)  (q_value)
    reg64_hi = (I32_IQ) reg64_hi >>(k2-qfmt) ;


    /* ============================================================================= */
    /* Step(5):   Determination  of the final angle                                  */
    /* ============================================================================= */


    output=IQatan2HalfPITable[qfmt]; 
    output_neg=_ssub(0,output);

    if(x>=0)
    {
        if(ax>=ay)
        {   
            reg64_los=reg64_hi;
            output = output_neg + output;
        }
        else 
        {
            reg64_los =_ssub(0,reg64_hi);
        }
    }
    else   
    { 
         if(ax>=ay)
         {
            reg64_los=_ssub(0,reg64_hi);
            output=_ssub(0,output_neg)+ output; 
         }
         else
         {
            reg64_los=reg64_hi;  
         }
    }
         output=output+reg64_los;


    if(y<0)
    {
        output= _ssub(0,output);
    }

    return(output);
}
/*###########################################################################
;;
;; FILE:    IQNatan2PU.c
;;
;; TITLE:   C-Model: IQNatan2PU function
;;
;;===========================================================================
;; Function:   _IQNatan2PU
;;===========================================================================
;;
;; C Usage:    extern long _IQNatan2PU(long Y, long X);
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4   = Y in IQ format
;;             B4   = X in IQ format
;;
;;
;; On Exit:    A4    = Per Unit result in IQ format (0.0=0Deg, 1.0=360Deg)
;;                      if( X == 0.0 and Y == 0.0 ), ACC = 0.0
;;                      if( Y >= 0.0 ), 0.0 <= ACC <= 0.5
;;                      if( Y <  0.0 ), 0.5 < ACC < 1.0
;;
;; Q range:    29 to 1
;;
;;             Note: A value of Q30 is not feasible since the result would
;;                   saturate for angles greater then +/- 2.0 radians.
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The algorithm steps to calculate the "atan2" of the given 
;;             input X and Y is as follows:
;;
;;             Step(1):   if( abs(X) >= abs(Y) )
;;                            Numerator   = abs(Y)
;;                            Denominator = abs(X)
;;                        else
;;                            Numerator   = abs(X)
;;                            Denominator = abs(Y)
;;
;;             Step(2):   Ratio = Numerator/Denominator
;;
;;                        Note: Ratio range = 0.0 to 1.0
;;
;;             Step(3):   Use the upper 6-bits of the "Ratio" value as an
;;                        index into the table to obtain the coefficients
;;                        for a second order equation:
;;
;;                        _IQNatan2Table:
;;                             CoeffA0[0]
;;                             CoeffA1[0]
;;                             CoeffA2[0]
;;                                .
;;                                .
;;                             CoeffA0[63]
;;                             CoeffA1[63]
;;                             CoeffA2[63]
;;
;;             Step(4):   Calculate the angle using the folowing equation:
;;
;;                        arctan(Ratio) = A0 + A1*Ratio + A2*Ratio*Ratio
;;                        arctan(Ratio) = A0 + Ratio(A1 + A2*Ratio)
;;
;;
;;             Step(5):   The final angle is determined as follows:
;;
;;                        if( X >= 0 and Y >= 0 and abs(X) >= abs(Y) )
;;                            Angle = arctan(abs(Y)/abs(X))
;;                        if( X >= 0 and Y >= 0 and abs(X) <  abs(Y) )
;;                            Angle = PI/2 - arctan(abs(X)/abs(Y))
;;                        if( X < 0  and Y >= 0 and abs(X) <  abs(Y) )
;;                            Angle = PI/2 + arctan(abs(X)/abs(Y))
;;                        if( X < 0  and Y >= 0 and abs(X) >= abs(Y) )
;;                            Angle = PI - arctan(abs(Y)/abs(X))
;;
;;             Step(6):   Convert to Per Unit (PU) value:
;;
;;                        PUangle(Ratio) = arctan(Ratio)/(2*pi)
;;                        PUangle(Ratio) = arctan(Ratio) * 0.159154943
;;                        PUangle(Ratio) = 0.0 to 0.5 
;;                        if( Y < 0 )
;;                            PUAngle(Ratio) = 1.0 - PUAngle(Ratio);
;;
;;                        PUangle(Ratio) = 0.0 (0deg) to 1.0 (360deg)
;;
;;===========================================================================*/

         


static inline I32_IQ _IQNatan2PU(I32_IQ y, I32_IQ x, U32_IQ qfmt)       
{

    const I32_IQ K = 0x28BE60DC;     // P = 1/(2*pi)       (Q32)          

    I64_IQ res_64;
    I32_IQ num,den,ax,ay,Dnorm,Dm,output,output_neg,ratio,reg64_hi,reg64_los;
    U32_IQ res_lo,res_hi,res_1,res,sbits,reg64_lo,index_new;
    U32_IQ var2;
    U32_IQ mask,mbits,temp1;
    const U32_IQ k1 = 32U, k2 = 30U;


    /* ============================================================================= */
    /* Step(1):   if( abs(X) >= abs(Y) )                                             */
    /*                    Numerator   = abs(Y)                                       */
    /*                    Denominator = abs(X)                                       */
    /*                  else                                                         */
    /*                    Numerator   = abs(X)                                       */
    /*                    Denominator = abs(Y)                                       */
    /* ============================================================================= */

    ax=_abs(x);
    ay=_abs(y);


    num=ay;             //if (ax>ay)
    den=ax;             //if (ax>ay)


    if(ax<ay)
    {
        num=ax;         //num=_min32(ax,ay);
        den=ay;
    }

    /* ============================================================================= */
    /* Step(2):   Ratio = Numerator/Denominator                                      */
    /* Note: Ratio range = 0.0 to 1.0                                                */
    /* ============================================================================= */

    sbits=_norm(den);
    temp1 = den; 
    Dnorm= (I32_IQ) (temp1 << sbits);

    if(Dnorm==0)
    {
        index_new=0;
    }
    else
    {
        index_new=((U32_IQ)Dnorm)>>22;
        index_new=index_new-254U;
        index_new= index_new>>1;
    }

    Dm=IQdivTable[index_new];
    res_64=_mpy32ll(Dm,Dnorm);      // 32 * 32 BIT MULTIPLICATION 
    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* =============================================================== */
    /* shift left by 1  (res_64=res_64 << 1)                           */
    /* =============================================================== */

    res = res_lo >> (31);
    res_1 = (res_hi << 1);
    reg64_hi = (I32_IQ) ( res | res_1);


    reg64_hi=0x40000000-reg64_hi;           // (5) ACC   = 2.0 - Dm*Dnorm  (Q29)


    res_64=_mpy32ll(Dm,reg64_hi);           // ACC:P = Dm(2.0 - Dm*Dnorm)  (Q61)
    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* =============================================================== */
    /* shift left by 3 (res_64=res_64 << 3)                            */
    /* =============================================================== */

    res = res_lo >> (29);
    res_1 = (res_hi << 3);

    reg64_hi = (I32_IQ) (res | res_1);
    Dm=reg64_hi;

    res_64=_mpy32ll(Dm,Dnorm);
    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* =============================================================== */
    /* shift left by 1  (res_64=res_64 << 1)                           */
    /* =============================================================== */

    res = res_lo >> (31);
    res_1 = (res_hi << 1);
    reg64_hi = (I32_IQ) (res | res_1);

    reg64_hi=0x40000000-reg64_hi;           // (5) ACC   = 2.0 - Dm*Dnorm      (Q29)
    res_64=_mpy32ll(Dm,reg64_hi);           // ACC:P = Dm(2.0 - Dm*Dnorm)  (Q61)

    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* =============================================================== */
    /* shift left by 3 (res_64=res_64 << 3)                            */
    /* =============================================================== */

    res = res_lo >> (29);
    res_1 = (res_hi << 3);
    reg64_hi = (I32_IQ) (res | res_1);

    res_64=_mpy32ll(num,reg64_hi);


    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* Extract the 32 bit result from 64 bit. */
    res = res_lo >> (30);
    res_1 = (res_hi << 2);

    reg64_hi = (I32_IQ) (res | res_1);
    reg64_lo = res_lo << 2;


    var2 = (I16_IQ) (62U - qfmt - sbits);
    if(var2 >31)                                
    {
        var2= (I16_IQ) (var2-32U);
        ratio= (I32_IQ) reg64_hi>>var2;
    }
    else
    {
        mask= (U32_IQ)(((1)<<var2)-1);
        mbits=(I32_IQ) reg64_hi & mask;
        mbits=mbits<< (k1-var2);

        ratio= (I32_IQ)(reg64_lo>>var2);
        ratio= (I32_IQ)(mbits|(U32_IQ)ratio);  
    }


    /* ============================================================================= */
    /* Step(3):   Use the upper 6-bits of the "Ratio" value as an                    */
    /*            index into the table to obtain the coefficients                    */
    /*            for a second order equation                                        */
    /* ============================================================================= */

    res_64=_mpy32ll(ratio,64);          // ACC = int(64*Ratio)
    res_lo = _loll(res_64);
    res_hi = _hill(res_64);


    /* =============================================================== */
    /* shift left (res_64 << (32-qfmt))                            */
    /* =============================================================== */
    res = res_lo >> qfmt;
    res_1 = (res_hi << (k1-qfmt));
    reg64_hi = (I32_IQ) (res | res_1);

    index_new=((I32_IQ)reg64_hi&0xffff)*3;          // Index = 3 * int(64*Ratio)

    /* ============================================================================= */
    /* Step(4):   arctan(Ratio) = A0 + A1*Ratio + A2*Ratio*Ratio                     */
    /*            arctan(Ratio) = A0 + Ratio(A1 + A2*Ratio)                          */
    /* ============================================================================= */

    res_64=_mpy32ll(ratio,IQatan2Table[index_new+2U]);
    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* =============================================================== */
    /* shift left (res_64 << (32-qfmt))                                */
    /* =============================================================== */
    res = res_lo >> (qfmt);
    res_1 = (res_hi << (k1-qfmt));
    reg64_hi = (I32_IQ) (res | res_1);

    reg64_hi=reg64_hi+IQatan2Table[index_new+1];


    res_64=_mpy32ll(ratio,reg64_hi);
    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* =============================================================== */
    /* shift left (res_64 << (32-qfmt))                                */
    /* =============================================================== */

    res = res_lo >> (qfmt);
    res_1 = (res_hi << (k1-qfmt));
    reg64_hi = (I32_IQ) (res | res_1);

    reg64_hi=reg64_hi+IQatan2Table[index_new];          // ACC   = A0 + Ratio(A1 + A2*Ratio)  (q_value)
    reg64_hi = (I32_IQ) reg64_hi >>(k2-qfmt) ;


    /* ============================================================================= */
    /* Step(5):   Determination  of the final angle                                  */
    /* ============================================================================= */


    output=IQatan2HalfPITable[qfmt]; 
    output_neg=_ssub(0,output);

    if(x>=0)
    {
        if(ax>=ay)
        {   
            reg64_los=reg64_hi;
            output = output_neg + output;
        }
        else 
        {
            reg64_los =_ssub(0,reg64_hi);
        }
    }
    else   
    { 
         if(ax>=ay)
         {
            reg64_los=_ssub(0,reg64_hi);
            output=_ssub(0,output_neg)+ output; 
         }
         else
         {
            reg64_los=reg64_hi;  
         }
    }
         output=output+reg64_los;


    /* ============================================================================= */
    /* Step(6):   Convert to Per Unit (PU) value:                                    */
    /*                                                                               */
    /*            PUangle(Ratio) = arctan(Ratio)/(2*pi)                              */
    /*            PUangle(Ratio) = arctan(Ratio) * 0.159154943                       */
    /*            PUangle(Ratio) = 0.0 to 0.5                                        */
    /*            if( Y < 0 )                                                        */
    /*            PUAngle(Ratio) = 1.0 - PUAngle(Ratio);                             */
    /* ============================================================================= */

    reg64_hi = (2 << (qfmt-1));
    res_64 = _mpy32ll(output, K);
    res_hi = _hill(res_64);

    output = (I32_IQ) (res_hi);
    reg64_hi = reg64_hi - output;
 
    if(y < 0)
    {
        output = reg64_hi;
    }

    return(output);
    
 
}



/*###########################################################################
;;
;; FILE:    IQNcos.c
;;
;; TITLE:   C-Model: IQcos function
;;

;;===========================================================================
;; Function:   _IQNcos
;;===========================================================================
;;
;; C Usage:    extern long _IQNcos(long Rad);
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4 = Radian in IQ format
;;
;; On Exit:    A4 = cos(Radian) result in IQ format
;;
;; Q range:    29 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The "cos" value is calculated as follows:
;;
;;             1) The offset into a 512 word sin/cos table is calculated:
;;
;;                 k = 0x1FF & (int(Radian*512/(2*pi)))
;;                 
;;
;;             2) The fractional component between table samples is
;;                calculated:
;;
;;                 x = fract(Radian*512/2*pi) * (2*pi)/512
;;
;;             3) The output sine value is calculated as follows:
;;
;;                 cos(Radian) = C(k) + x*(-S(k) + x*(-0.5*C(k) + 0.166*x*S(k)))
;;
;;                 where  S(k) = Sin table value at offset "k"
;;                        C(k) = Cos table value at offset "k"
;;
;;             Using the above method, with a 512x32 full wave sin/cos table,
;;             will give an accuracy of approximately 29 bits.
;;=========================================================================*/




  

static inline I32_IQ _IQNcos(I32_IQ in, U32_IQ qfmt)        
{

    const I32_IQ K = 0x2AAA;                    // 1/6 in Q16

    I64_IQ reg64;
    I32_IQ high,low,x,z;
    U32_IQ res, lowp,y,high_new;
    I16_IQ index_new;
    const I32_IQ k1 = 0x03243F6B, k2 = 0x517CC1B7,k3 = 30;   // K1=(2*pi)/512 = 0x03243F6B (Q32)
    // K2=512/(2*pi) = 0x517CC1B7 (I8Q24)


    /* ========================================== */
    /* high is made to contain integer part.....  */
    /* low contains fractional part..........     */
    /* ========================================== */


    /* unsigned 32 * 32 multiplication  */
    y=_abs(in);
    reg64 = _mpy32us(y, k2);                 // reg64: Q+24
    high = (I32_IQ)_hill(reg64);
    lowp = _loll(reg64);

    if(qfmt >= 9) {

        /* right shift by (qfmt -8 )  */
        high_new = (U32_IQ)(high);
        res = 40u - qfmt;
        res = high_new << (res);

        high_new  = high_new >> ( qfmt - 8u);
        high = (I32_IQ)high_new;

        lowp >>= (qfmt - 8u);
        lowp |= res;

    }
    else{
        /* Left shift by (8 - qfmt)  */
        res = (24u + qfmt);
        res = lowp >> (res);
        high_new = (U32_IQ)(high);
        y = (8u - qfmt);
        high_new  = high_new << (y);
        high = (I32_IQ)high_new;
        lowp <<= (y);
        high_new = (U32_IQ)(high);
        high_new |= res;
        high = (I32_IQ)high_new;

    }

    /* ===================================================================== */
    /* Step(1):The fractional component between table samples is calculated: */
    /*           x = fract(Radian*512/2*pi) * (2*pi)/512                     */
    /* ===================================================================== */
    reg64 = _mpy32us(lowp, k1);                             // Interpolation
    x =(I32_IQ) _hill(reg64); 

    /* ================================================================ */
    /* Step(2):The offset into a 512 word sin/cos table is calculated:  */
    /*       k = 0x1FF & (int(Radian*512/(2*pi)))                       */
    /* ================================================================ */
    high_new = (U32_IQ)(high);
    index_new = (I16_IQ)(high_new & 0x1ffu);

    high = -IQsinTable[index_new + 128];
    /* ============================================================================== */
    /* Step(3): The output sine value is calculated as follows:                       */
    /*                 cos(Radian) = C(k) + x*(-S(k) + x*(-0.5*C(k) + 0.166*x*S(k)))  */ 
    /*                 where  S(k) = Sin table value at offset "k"                    */
    /*                        C(k) = Cos table value at offset "k"                    */
    /* ===============================================================================*/

    high = (I32_IQ)high >> 1;                                  // ACC = -0.5*C(k)                (Q30)


    reg64 = _mpy32ll(x, IQsinTable[index_new]);               // P   = x*S(k)                   (Q30)
    z=(I32_IQ)_hill(reg64);
    low = _mpyhl( z, K);                     // P   = 0.166*x*S(k)             (Q30)
    high = high + low;

    reg64 = _mpy32ll(x, high);
    high = (I32_IQ)_hill(reg64);                                // ACC = x*(-0.5*C(k) + 0.166*x*S(k)) (Q30)

    high = high - IQsinTable[index_new];

    reg64 = _mpy32ll(x, high);
    high = (I32_IQ)_hill(reg64);
    high = high + IQsinTable[index_new + 128];             // ACC = C(k) + x*(-S(k) + x*(-0.5*C(k) + 0.166*x*S(k))) (Q30) 


    high = (I32_IQ)high >> (k3 - qfmt);

    return high;
}

/*###########################################################################
;;
;; FILE:    IQNcosPU.c
;;
;; TITLE:   C-Model: IQcosPU function
;;

;;===========================================================================
;; Function:   _IQNcosPU
;;===========================================================================
;;
;; C Usage:    extern long _IQNcosPU(I32_IQ Rad);
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4 = Radian in IQ format
;;
;; On Exit:    A4 = cosPU result in IQ format
;;
;; Q range:    30 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The "cos" value is calculated as follows:
;;
;;             1) The offset into a 512 word sin/cos table is calculated:
;;
;;                 k = 0x1FF & (int(PU*512))
;;                 
;;
;;             2) The fractional component between table samples is
;;                calculated:
;;
;;                 x = fract(PU*512) * (2*pi)/512
;;
;;             3)
;;             Using the above method, with a 512x32 full wave sin/cos table,
;;             will give an accuracy of approximately 29 bits.
;;
;;--------------------------------------------------------------------------*/


          

static inline I32_IQ _IQNcosPU(I32_IQ in, U32_IQ qfmt)
{
    const I32_IQ K = 0x2AAA;                    // 1/6 in Q16

    I64_IQ reg64;
    I32_IQ high, low, x,y;
    U32_IQ high_new,z;
    I16_IQ index_new;
    const I32_IQ k1 = 0x03243F6B,k2 = 30;      // K1=(2*pi)/512 = 0x03243F6B (Q32)

    /* ========================================== */
    /* high is made to contain integer part.....  */
    /* low contains fractional part..........     */
    /* ========================================== */
    high = _abs(in);
    low = 0;


    if(qfmt >= 9)
    {

        high_new = (U32_IQ)(high);
        z=(32u - (qfmt - 9u));
        low  =(I32_IQ)(high_new << z);
        high = (I32_IQ)high_new;
        high_new = (U32_IQ)(high);
        high_new  = high_new >> ( qfmt - 9u);
        high = (I32_IQ)high_new;
    }
    else
    {
        high_new = (U32_IQ)(high);
        z = (9u - qfmt);
        high_new  = high_new << (z);
        high = (I32_IQ)high_new;
    }

    /* ================================================================= */
    /* Step(1): The offset into a 512 word sin/cos table is calculated:  */ 
    /*                 k = 0x1FF & (int(PU*512))                         */
    /* ================================================================= */
        high_new = (U32_IQ)(high);
        index_new = (I16_IQ)(high_new & 0x1ffu);

    /* ================================================================== */
    /* Step(2):The fractional component between table samples is          */
    /*                calculated:                                         */
    /*                 x = fract(PU*512) * (2*pi)/512                     */
    /* ================================================================== */

    reg64 = _mpy32us((U32_IQ)low, k1);
    x =(I32_IQ)_hill(reg64);                              // Interpolation

    /* =================================================================== */
    /* Step(3):  The output sine value is calculated as follows:           */
    /*    cos(Radian) = C(k) + x*(-S(k) + x*(-0.5*C(k) + 0.166*x*S(k)))    */
    /*                 where  S(k) = Sin table value at offset "k"         */
    /*                        C(k) = Cos table value at offset "k"         */
    /* =================================================================== */

    high = -IQsinTable[index_new + 128];
    high = (I32_IQ)high >> 1;                                // ACC = -0.5*C(k)                (Q30)

    reg64 = _mpy32ll(x, IQsinTable[index_new]);     // P   = x*S(k)                   (Q30)
    y= (I32_IQ)(_hill(reg64));
    low = _mpyhl(y, K);             // P   = 0.166*x*S(k)             (Q30)

    high += low;


    reg64 = _mpy32ll(x, high);
    high = (I32_IQ)_hill(reg64);                       // ACC = x*(-0.5*C(k) + 0.166*x*S(k)) (Q30)

    high -= IQsinTable[index_new];

    reg64 = _mpy32ll(x, high);
    high = (I32_IQ)_hill(reg64);
    high += IQsinTable[index_new + 128];            // ACC = C(k) + x*(-S(k) + x*(-0.5*C(k) + 0.166*x*S(k))) (Q30) 

    high = (I32_IQ)high >> (k2 - qfmt);
    return high;
}


/*###########################################################################
;;===========================================================================
;; Function:   _IQNdiv
;;===========================================================================

;; (for C64x+ processors )
;; C Usage:    extern int _IQNdiv(int Num, int Den);
;;
;; (for C28x processors )
;; C Usage:    extern long _IQNdiv(long Num, long Den);
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = Numerator in IQ format
;;             B4    = Denominator in IQ format
;;
;; On Exit:    A4     = Num/Den result in IQ format
;;                    = 0x7FFFFFFF if +ve overflow
;;                    = 0x80000000 if -ve overflow
;;                    = 0x7FFFFFFF if Den == 0
;;
;; Q range:    31 to 0
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The procedure for calculating Y = N/D is as follows:
;;
;;             Step 1) Normalize Input: 
;;
;;                     Dnorm = D * 2^n 
;;
;;             Step 2) Obtain initial estimate of Dm = 1/Dnorm from 
;;                     "_IQdivTable" using the upper 8-bits of the 
;;                     normalized value.
;;
;;             Step 3) Use Newton-Raphson algorithm to improve accuracy.
;;                     Repeat following equation two times. First iteration
;;                     gives 16-bit accuracy. Second iteration gives 32-bit
;;                     accuracy:
;;
;;                     Dm = 2(Dm - Dm^2*Dnorm/2)   
;;
;;             Step 4) Multiply by numerator value:
;;
;;                     Ym = N * Dm
;;
;;             Step 5) Denormalize result, saturate and round:
;;
;;                     Y = Ym >> n 
;;
;;--------------------------------------------------------------------------*/







static inline I32_IQ _IQNdiv(I32_IQ num, I32_IQ den, U32_IQ qfmt)     
{ 

    I32_IQ Dnorm, Dm, hi, lo, hi2, lo2;
    
    U32_IQ sbits, t1, var2, offset, hi1, lo1;
    I64_IQ reg64;
    I64_IQ temp3, temp1;
    const U32_IQ k = 0x20U;


    /* =========================================================================*/
    /* Step 1) Normalize Input:                                                 */              
    /*          Dnorm = D * 2^n                                                 */          
    /* =========================================================================*/

    sbits = _norm(den);
    hi1 = den;
    Dnorm = (I32_IQ)(hi1 << sbits);

    /*==========================================================================*/
    /* Step 2)  Obtain initial estimate of Dm = 1/Dnorm from                    */
    /*          "_IQdivTable" using the upper 8-bits of the                     */
    /*          normalized value.                                               */
    /* =========================================================================*/

    t1 = qfmt + sbits;
    var2 = (59U - t1);
    offset = (U32_IQ)Dnorm >> 23U; 
    offset = offset - 127U;    

    Dm=IQdivTable[offset];
    /* =========================================================================*/
    /* Step 3)  Use Newton-Raphson algorithm to improve accuracy.               */
    /*          Dm = 2(Dm - Dm^2*Dnorm/2)                                       */              
    /*          1ST iteration                                                   */
    /* =========================================================================*/

    reg64 = _mpy32ll(Dm, Dnorm) ;
    lo1 = _loll(reg64) >> 31U ;
    hi1 = _hill(reg64) << 1U ;
    lo1 = lo1 + hi1;
    /* =========================================================================*/
    /* IQdivRoundSatTable[0]= 0x40000000                                        */              
    /* =========================================================================*/
    hi1 = 0x40000000U - lo1;
    reg64 = _mpy32su(Dm, hi1) ; 
    lo1 = _loll(reg64) >> 29U ;
    hi = (I32_IQ)(_hill(reg64) << 3U);
    lo = (I32_IQ)(lo1 + hi);
    /* =========================================================================*/
    /*  Step 3) Use Newton-Raphson algorithm to improve accuracy.               */
    /*          Dm = 2(Dm - Dm^2*Dnorm/2)                                       */              
    /*          2nd iteration                                                   */              
    /* =========================================================================*/


    Dm = lo ;
    reg64 = _mpy32ll(Dm, Dnorm) ;

    lo1 = _loll(reg64) >> 31U ;
    hi1 = _hill(reg64) << 1U ;
    lo1 = lo1 + hi1;
    /* =========================================================================*/
    /* IQdivRoundSatTable[0]= 0x40000000                                        */              
    /* =========================================================================*/

    hi1 = 0x40000000U - lo1;
    reg64 = _mpy32su(Dm, hi1) ; 
    lo1 = _loll(reg64) >> 29U ;
    hi = (I32_IQ)(_hill(reg64) << 3U);
    lo = (I32_IQ)(lo1 + hi);
    
    /* =========================================================================*/
    /* Step 4) Multiply by numerator value:                                     */
    /*         Ym = N * Dm                                                      */
    /* =========================================================================*/

    reg64 = _mpy32ll(num, lo);
    /* =========================================================================*/
    /* Step 5) Denormalize result, saturate and round:                          */
    /*          Y = Ym >> n                                                     */
    /* =========================================================================*/

    hi2 = _SHR( ((I32_IQ)_hill(reg64)), var2);  //  ((I32_IQ)_hill(reg64)) >> var2;
    lo1 = _SHR( (_loll(reg64)), var2);          //  (_loll(reg64)) >> var2;
    lo1 = _SHL( _hill(reg64), (k - var2)) + lo1; // (_hill(reg64) << (k - var2)) + lo1;

    if( var2 > 31)                                
    {   
        hi2 = ((I32_IQ)_hill(reg64) < 0) ? -1 : 0;
        lo1 = _SHR( ((I32_IQ)_hill(reg64)), (var2 - 32U) );  // (I32_IQ)_hill(reg64) >> (var2 - 32U);
    }
    /* =========================================================================*/
    /* replaced IQdivRoundSatTable[1]= 0x00000001                               */              
    /* =========================================================================*/
    temp1 = lo1;
    temp3 = temp1 + 0x00000001U;  
    lo1 = _loll(temp3);
    lo2 = (I32_IQ)_hill(temp3);
    hi = _sadd(hi2,lo2);
    /* =========================================================================*/
    /*  IQdivRoundSatTable[3]= 0xFFFFFFFE                                       */              
    /*  IQdivRoundSatTable[4]= 0x00000000                                       */              
    /* =========================================================================*/

    if(((hi > 0) && (lo1 <= 0xfffffffe)) || ((hi == 0) && (lo1 == 0xffffffff)) )
    {
        lo1 = 0xFFFFFFFE;
        hi = 0x00000000;
    }
    /* =========================================================================*/
    /*    IQdivRoundSatTable[5]= 0x00000000                                     */              
    /*    IQdivRoundSatTable[6]= 0xFFFFFFFF                                     */              
    /* =========================================================================*/

    if( hi < (I32_IQ)0xffffffff)
    {
        lo1 = 0x00000000;
        hi = (I32_IQ)0xFFFFFFFF;
    }

    lo1 = lo1 >> 1U;
    hi1 = (U32_IQ)hi << 31U ;
    lo = (I32_IQ)(lo1 + hi1);

    return(lo);
}
/*###########################################################################
;;
;; FILE:    IQNexp.c
;;
;; TITLE:   IQ Exponent Math Function
;;

;;===========================================================================
;; Function:   _IQNexp
;;===========================================================================
;; C Usage:    extern int _IQNexp(int X);   // Saturated
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = X in IQ format
;; On Exit:    A4    = exp(X) result in IQ format
;;
;; Q range:    29 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The procedure for calculating "Y = exp(X)" is as follows:
;;
;;             Step 1) Saturate input to avoid overflow.
;; 
;;             Step 2) Normalize Input: 
;;
;;                     X' = X * 2^n           -1.0 <= X' < 1.0
;;
;;             Step 3) Obtain Y' = exp(X') using taylor series expansion:
;;
;;                     Y' = 1 + X' + X'^2/2! + .... + X^11/11!
;;
;;             Step 4) Denormalize value to get output Y:
;;
;;                     if( n == 0 ) Y = Y'
;;                     if( n == 1 ) Y = Y'^2
;;                     if( n == 2 ) Y = Y'^4
;;                     if( n == 3 ) Y = Y'^8
;;                     if( n == 4 ) Y = Y'^16
;;        
;;--------------------------------------------------------------------------*/



static inline I32_IQ _IQNexp(I32_IQ in, U32_IQ qfmt)
{
    const I32_IQ K = 0x20000000;      // 1.0 in Q29 

    I32_IQ Dnorm,acc,min,max,X,Y,i,coeff,int_part,offset,sbits,index;
    I64_IQ reg64;

    
    /* ========================================= */
    /* Step(1):Saturate input to avoid overflow  */
    /* ========================================= */    
    index = (qfmt - 1) << 1;


    max = IQexpTableMinMax[index];
    min = IQexpTableMinMax[index + 1];
        
    if(in < min)
        in = min ;
    if(in > max)
        in = max ;
        
    /* ========================================= */ 
    /*             Step 2) Normalize Input:      */
    /*                                           */   
    /*  X' = X * 2^n           -1.0 <= X' < 1.0  */
    /* ========================================= */ 
    
    sbits = _norm(in);
    offset = 31 - qfmt ;
    int_part = offset - sbits ;

    if(int_part < 0 )
        int_part = 0;

    reg64 = _dmv(in,0);
    reg64 = reg64 >> int_part ;

    
    /* ========================================= */ 
    /* value is well within range -1 and +1      */
    /* ========================================= */ 
    
    if(qfmt <= 29 )
        reg64 = reg64 << (29 - qfmt);
        
    Dnorm = _hill(reg64);
    X = Dnorm ;
    
    /* =========================================================== */ 
    /* Step 3) Obtain Y' = exp(X') using taylor series expansion   */
    /*          Y' = 1 + X' + X'^2/2! + .... + X^11/11!            */
    /* =========================================================== */ 
    
    for(i = 0;i < 10 ; i++)
    {
        coeff = IQexpTableCoeff[i];  // Q31 format
        reg64 = _mpy32su(X,coeff);   // the product can be represented as Q31 format 
        reg64 = reg64 << 1 ;
        acc = _hill(reg64) + K;
        reg64 = _mpy32us(acc,Dnorm); //Q29 * Q29 = I6Q58
        reg64 <<= 3 ;                //maintain Q29  
        X = _hill(reg64);
    }
    
    Y = X + K;
    X = Y >> (29 - qfmt);

    if(int_part == 0)
        Y = X;      // return value
    else 
    {

        reg64 = _mpy32ll(Y, Y);
        reg64 <<= 3;
        Y = _hill(reg64);
        Y = (U32_IQ)Y >> (29 - qfmt);


       /* =========================================================== */ 
       /*        Step 4) Denormalize value to get output Y            */
       /* =========================================================== */ 

        for(i = 1;i < int_part; i++)
        {
            reg64 = _mpy32ll(Y, Y);
            reg64 <<= (32 - qfmt);
            Y = _hill(reg64);
        }
    }

    return(Y);

}


/*###########################################################################
;;
;; FILE:    IQNfrac.c
;;
;; TITLE:   C-Model: _IQNfrac function
;;
;;===========================================================================
;; Function:   _IQNfrac
;;===========================================================================
;;
;; C Usage:    extern int _IQfrac(int A);   // no round or sat
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = A in IQ format
;; On Exit:    A4    = fractional portion of A stored as IQ
;;                       
;; Q range:    31 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The fractional portion of the IQ number is calculated
;;             as follows:
;;
;;                frac = A - ((A >> q_value) << q_value);
;;          
;;---------------------------------------------------------------------------*/




static inline I32_IQ _IQNfrac(I32_IQ f1, U32_IQ var2)
{
    I32_IQ temp1;
    U32_IQ temp;
    U32_IQ reg = 1;
    temp1 = _abs(f1);
    temp= (U32_IQ) temp1;
        
    /* ======================================================================== */
    /*  Find a mask to extract fractional bits                                  */
    /* ======================================================================== */
            
    reg = reg << var2;
    reg = reg - 1;                
    temp = temp & reg;
    temp1 = (I32_IQ)temp;
                
    /* ======================================================================== */
    /*  check if negative                                                       */
    /* ======================================================================== */

    if(f1 < 0)  
    {               
        temp1 = -temp1;
    }
    return(temp1);
}
/*###########################################################################
;;
;; FILE:    IQNint.c
;;
;; TITLE:   C-Model: _IQNint function
;;
;;===========================================================================
;; Function:   _IQNint
;;===========================================================================
;;
;; C Usage:    extern int _IQint(int A);   // no round or sat
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = A in IQ format
;; On Exit:    A4    = integer portion of A stored as "long"
;;                       
;; Q range:    29 to 0
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The integer portion of the IQ number is calculated
;;             as follows:
;;
;;                integer = A >> q_value;
;;          
;;---------------------------------------------------------------------------*/




static inline I32_IQ _IQNint(I32_IQ input,U32_IQ qfmt)       
{
    I32_IQ reg;
    U32_IQ temp;
    reg = _abs(input);
    temp= (U32_IQ)reg;

    /* ======================================================================== */
    /*  shift to remove the fractional components                               */
    /* ======================================================================== */

    temp = temp >> qfmt;
    reg= (I32_IQ)temp;

    /* ======================================================================== */
    /*  check if negative                                                       */
    /* ======================================================================== */
    
    if(input < 0)   
    {               
        reg = -reg;
    }
    return(reg);
}


/*###########################################################################
;;
;; FILE:    IQNisqrt.c
;;
;; TITLE:   C-Model: _IQNisqrt function
;;
;;===========================================================================
;; Function:   _IQNisqrt
;;===========================================================================
;;
;; C Usage:    extern long _IQNisqrt(long X); // with saturation and rounding
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = Val in IQ format

;; On Exit:    A4    = 1/sqrt(X) result in IQ format
;;             A4    = 0 if input is -ve or 0
;;             A4    = max value "0x7FFFFFFF" if result saturates
;;
;; Q range:    30 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The procedure for calculating "Y = 1/sqrt(X)" is as follows:
;;
;;             Step 1) Normalize Input: 
;;
;;                     V = X * 2^n 
;;
;;             Step 2) Obtain initial estimate from "_IQisqrtTable" 
;;                     using the upper 8-bits of the normalized V value.
;;
;;             Step 3) Use Newton-Raphson algorithm to improve accuracy.
;;                     Repeat following equation two times. First iteration
;;                     gives 16-bit accuracy. Second iteration gives 32-bit
;;                     accuracy:
;;
;;                     y = y(1.5 - y*y*V/2)
;;
;;                     y = 1/sqrt(V)
;;
;;             Step 4) Denormalize result, round and saturate:
;;
;;                     Y = y / sqrt(2^n)
;;        
;;---------------------------------------------------------------------------*/





static inline I32_IQ _IQNisqrt(I32_IQ x, U32_IQ qfmt)     
{

    I64_IQ reg64;
    U32_IQ low, res,high_new,z_qfmt,z_sbits,tmp;
    I32_IQ Dnorm, y = 0, high, index_new;//,tmp
    Uword40 tmp1, tmp2;
    U32_IQ sbits;
    const I32_IQ k1 = 127,k2 =28, k3 =3, k4 =86,k5=0x00008000;
    const U32_IQ k6 = 32u;

    /* Step(1):  Normalize Input:  V = X * 2^n */


    sbits = (U16_IQ)_norm(x); 
    high = x;
    low = 0;

    high_new = (U32_IQ)high;
    high_new <<=sbits;
    high = (I32_IQ)high_new;
    Dnorm = high;
    /* =========================================================== */
    /* Step(2):Obtain initial estimate from "_IQisqrtTable"        */
    /* using the upper 8-bits of the normalized V value.           */
    /* =========================================================== */

    if(Dnorm > 0){
        index_new = (I16_IQ)(((U32_IQ)Dnorm) >> 23);
        index_new = index_new - k1;
        y = IQisqrtTable[index_new];
    }


    /* ================================================================= */
    /* Step(3):Use Newton-Raphson algorithm to improve accuracy.         */
    /* Repeat following equation two times. First iteration              */
    /* gives 16-bit accuracy. Second iteration gives 32-bit              */
    /* accuracy:                                                         */
    /*     y = y(1.5 - y*y*V/2)                                      */
    /*     y = 1/sqrt(V)                                                */
    /* ================================================================= */


    reg64 = _mpy32ll(y, y);
    high = (I32_IQ)_hill(reg64);
    high_new = (U32_IQ)high;
    high_new <<=2;
    high = (I32_IQ)high_new;



    reg64 = _mpy32ll(Dnorm, high);
    high = (I32_IQ)_hill(reg64);
    high = 0x60000000 - high;        //1.5 - y*y*V/2



    reg64 = _mpy32ll(y, high);
    high = (I32_IQ)_hill(reg64);
    high_new = (U32_IQ)high;
    high_new <<= 2;
    high = (I32_IQ)high_new;

    y = high;

    reg64 = _mpy32ll(y, y);
    high = (I32_IQ)_hill(reg64);
    high_new = (U32_IQ)high;
    high_new <<=2;
    high = (I32_IQ)high_new;


    reg64 = _mpy32ll(Dnorm, high);
    high = (I32_IQ)_hill(reg64);
    high = 0x60000000 - high;   //1.5 - y*y*V/2


    reg64 = _mpy32ll(y, high);
    high = (I32_IQ)_hill(reg64);
    high_new = (U32_IQ)high;
    high_new <<=2;
    high = (I32_IQ)high_new;

    z_qfmt = qfmt << 31; 
    z_sbits = (I32_IQ)(sbits << 31);

    if((z_qfmt) == 0) {     //Qfmat == even.....(qfmt & 0x1)
        if(z_sbits != 0) 
        {
            reg64 = _mpy32ll(high, 0x40000000); //IQisqrtRoundSatTable[5]
        }
        else
        {
            reg64 = _mpy32ll(high, 0x2D413CCD); //IQisqrtRoundSatTable[7]
        }
    }
    else {                  //Qfmat == odd
        if(z_sbits != 0) 
        {
            reg64 = _mpy32ll(high, 0x2D413CCD); //IQisqrtRoundSatTable[7]
        }
        else
        {
            reg64 = _mpy32ll(high, 0x20000000); //IQisqrtRoundSatTable[6]
        }
    }             
    low = _loll(reg64);
    high = (I32_IQ)_hill(reg64);

    if(qfmt > 28)
    {

        /* Shift left by tmp   */
        tmp = (I32_IQ)qfmt - k2;
        res = _SHR(low, (k6 - tmp));    //  (low >>(k6 - tmp));

        high = (I32_IQ)((U32_IQ)high << tmp);

        low <<= tmp;
       high = (I32_IQ)((U32_IQ)high | res);


    }
    else
    {

        /* shift right by tmp   */

        tmp = (k4-((I32_IQ)qfmt * k3));
        tmp >>= 1;
        if (tmp > 31) {
            tmp = tmp - k6;
            high_new = high;
            low = (I32_IQ)_SHR(high_new, tmp);  //  (high_new >> tmp);
            high = 0; 
        }
        else{

            high_new = high;
            res = _SHL(high_new, (k6 - tmp));   //  high_new << (k6 - tmp);

            high_new = high;
            high = (I32_IQ)(high_new >> tmp);
            low>>=tmp;
            low |=res;
        }
    }

    /* shifting right by 16 bits     */
    low = _packlh2((U32_IQ)high, low);
    high_new = high;
    high = (I32_IQ)(high_new >> 16);
 

    /* ==================================================== */
    /* Step(4): Denormalize result, round and saturate:     */
    /*                     Y = y / sqrt(2^n)               */
    /* ==================================================== */

    /* shifting left by tmp */
    tmp = (sbits >> 1);
    res = _SHR(low, (k6 - tmp));    //  low >> (k6 - tmp);
    high_new = high;
    high = (I32_IQ)(high_new << tmp);
    low <<= tmp;
    high_new = high;
      high = (I32_IQ)(high_new | res);

    /* adding 2 64 bit numbers */
    tmp1 = low;
    tmp2 = tmp1 + k5;//   IQisqrtRoundSatTable[1]
    low = (U32_IQ)tmp2;


    res = _hill((I64_IQ)tmp2);
    high = _sadd(high, (I32_IQ)res);

    /* checking for saturation */
    if(high > 0x00007FFF) {        //........IQisqrtRoundSatTable[4]
        high = 0x00007FFF;          //........IQisqrtRoundSatTable[4]
        low = 0xFFFF0000;          //........IQisqrtRoundSatTable[3]
    } 
    /* shifting left by 16 bits */
    high = (I32_IQ)_packlh2((U32_IQ)high, low);
    return high;
}
/*###########################################################################
;;
;; FILE:    IQNlog.c
;;
;; TITLE:   IQ Logarithmic Math Function
;;

;;===========================================================================
;; Function:   _IQNlog
;;===========================================================================
;;(for C64x+ processor)
;; C Usage:    extern int _IQNlog(int X);   // Saturated
;;
;;(for C28x processor)
;; C Usage:    extern long _IQNlog(long X);   // Saturated;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = X in IQ format
;; On Exit:    A4    = log(X) result in IQ format
;;
;; Q range:    29 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The procedure for calculating "Y = log(X)" is as follows:
;;
;;             Step 1) Saturate input to avoid overflow.
;; 
;;             Step 2) Normalize Input: 
;;
;;                     X' = X * 2^n           -1.0 <= X' < 1.0
;;
;;             Step 3) Obtain Y' = log(X') using taylor series expansion:
;;                      y = (X'-1)/(X'+1)
;;
;;                     Y' = 2y (1 + y^2(1/3 + y^2(1/7 + y^2(1/9 + ........)))
;;
;;             Step 4) Denormalize value to get output 
;;
;;
;;--------------------------------------------------------------------------*/





static inline I32_IQ _IQNlog(I32_IQ x, U32_IQ qfmt)
{
    const I32_IQ K   = 0x20000000;      // 1.0 in Q29 
    const I32_IQ ln2 = 0x162E42FE;

    I32_IQ acc,in,X,Y,Y2, i,coeff,int_part,offset,sbits;
    I64_IQ reg64;
    
    if(x < 0)
    return 0;

    sbits = _norm(x);
    offset = 31 - qfmt ;
    int_part = offset - sbits ;

    if(int_part < 0 )
        int_part = 0;

    reg64 = _dmv(x,0);
    reg64 = reg64 >> int_part ;
    reg64 = reg64 << (29 - qfmt);

    in = _hill(reg64);


    acc = in + K;            //(x + 1)
    X = in - K;              // (x - 1) 
    Y = _IQ29div(X, acc);    //(x - 1)/(x + 1) 
    reg64 = _mpy32ll(Y, Y);
    reg64 <<= 3;
    Y2 = _hill(reg64);
    
    X = Y2 ;                    //y^2
    for(i = 0;i < 10 ; i++)
    {
        coeff = IQlogTableCoeff[i];  // Q29 format
        acc = coeff + X;             //1/11 + y^2
        reg64 = _mpy32su(Y2, acc);   // the product can be represented as Q31 format 
        reg64 = reg64 << 3 ;
        X = _hill(reg64);
    }
    
    X = X + K;
    reg64 = _mpy32ll(Y, X);
    reg64 <<= 3;
    Y = _hill(reg64);
    Y <<= 1;
    
    X = Y >> (29 - qfmt);

    for(i = 0 ;i < int_part ; i++)
    {
        X = X + (ln2 >> (29 - qfmt));   
        
    }
        return(X);

}

/*###########################################################################
;;
;; FILE:    IQNmag.c
;;
;; TITLE:   C-Model: _IQNmag function
;;
;;===========================================================================
;; Function:   _IQNmag
;;===========================================================================
;;
;; C Usage:    extern long _IQNmag(long A, long B); // with rounding & sat
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = A in IQ format
;;             B4    = B in IQ format
;;
;; On Exit:    A4    = sqrt(A*A + B*B) result in IQ format
;;
;; Q range:    30 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  To calculate the magnitute we basically use the sqrt function.
;;             The procedure for calculating "Y = sqrt(X)" is similar
;;             to calculating the inverse sqare root due to the
;;             following relationship:
;;
;;                     sqrt(X) = X * 1/sqrt(X)
;;
;;             The procedure is as follows:
;;
;;             Step 1) Calculate value to square root:
;;
;;                     X = (A*A + B*B)
;;
;;             Step 2) Normalize Input: 
;;
;;                     V = X * 2^n 
;;
;;             Step 3) Obtain initial estimate from "_IQsqrtTable" 
;;                     using the upper 8-bits of the normalized V value.
;;
;;             Step 4) Use Newton-Raphson algorithm to improve accuracy.
;;                     Repeat following equation two times. First iteration
;;                     gives 16-bit accuracy. Second iteration gives 32-bit
;;                     accuracy:
;;
;;                     Yn = Yn(1.5 - Yn*Yn*V/2)
;;
;;                     Yn = 1/sqrt(V)
;;
;;             Step 5) Caculate the square root of the normalized number:
;;
;;                     Yn = V * Yn
;;
;;             Step 6) Denormalize result and round:
;;
;;                     Y = Yn * 2^n / sqrt(2^n)
;;
;;---------------------------------------------------------------------------*/




static inline I32_IQ _IQNmag(I32_IQ x, I32_IQ y, U32_IQ qfmt)     
{
    I64_IQ reg64;
    U32_IQ low1, low2, res,high_new;
    I32_IQ Dnorm=0, yn_new=0, high1, high2;
    I16_IQ index_new;

   U64_IQ tmp1, tmp2, tmp3;
   U16_IQ sbits,n,nn;
   

    /* ======================================   */
    /* Step(1):Calculate value to square root   */
    /* X = (A*A + B*B)                          */
    /* ======================================   */

    reg64 = _mpy32ll(x, x);
    high1 = (I32_IQ)_hill(reg64);
    low1  = _loll(reg64);

    /*  A*A */

    reg64 = _mpy32ll(y, y);
    high2 = (I32_IQ)_hill(reg64);
    low2  = _loll(reg64);

    /* B*B */

    /* ============================================================================= */
    /* code for  _add64(&reg64,&t64)....unsigned addition is performed  on           */
    /* lower 32 bits.An intrinsic _sadd() is used to add upper 32 bits.              */ 
    /* If a carry is generated during lower 32 bit addition,acc is incremented by one*/
    /* ============================================================================= */

     tmp1 = low1;
     tmp2 = low2;
     tmp3 = tmp1 + tmp2;

    low1 = (U32_IQ)tmp3;
    high1 = _sadd(high1, high2);
    res = _hill(tmp3);  // (U32_IQ)((U64_IQ)tmp3 >> 32);
    high1  =  _sadd(high1, (I32_IQ)res);

    /* high1=(A*A + B*B)  */

    /* ========================================= */
    /* Step(2):Normalize Input:                  */
    /*  V = X * 2^n                              */
    /* ========================================= */

    sbits = (U16_IQ)_norm(high1);


    /* =========================================================== */
    /* shifting left a 64 bit number...the number is split into    */
    /* 2 32 bits and shifted.........                              */
    /* =========================================================== */

    res = _SHR(low1, 32 - sbits);   // low1 >> (32 - sbits);
    high_new = high1;
    high1 = (I32_IQ)(high_new << sbits);

    high_new = high1;
    high1 = (I32_IQ)(high_new | res);

    n = sbits;
    sbits = (U16_IQ)_norm(high1);    
    n = (U16_IQ)(n + sbits);

    res = _SHR(low1, 32 - sbits);   // low1 >> (32 - sbits);
    high_new = high1;
    high1 = (I32_IQ)(high_new << sbits);

    high_new = high1;
    high1 = (I32_IQ)(high_new | res);
  


    /* V=high1 */

    /* ===================================================== */
    /* Step(3):Obtain initial estimate from "_IQsqrtTable"   */
    /* using the upper 8-bits of the normalized V value.     */
    /* ===================================================== */
    if(high1 > 0){
        index_new = (I16_IQ)(((U32_IQ)high1) >> 23);
        index_new = (I16_IQ)(index_new - 127);
        yn_new = IQisqrtTable[index_new];
    } 

    /* yn=Initial Estimate */


    /* ============================================================= */
    /* Step(4): Use Newton-Raphson algorithm to improve accuracy.    */
    /*  Repeat following equation two times. First iteration         */
    /*  gives 16-bit accuracy. Second iteration gives 32-bit         */ 
    /*  accuracy:                                                    */ 
    /*  Yn = Yn(1.5 - Yn*Yn*V/2)                                     */
    /*  Yn = 1/sqrt(V)                                               */
    /* ============================================================= */

    Dnorm = high1;
    reg64 = _mpy32ll(yn_new, yn_new);
    high1 = (I32_IQ)_hill(reg64);
    low1 = 0;
    high_new = high1;
    high1 = (I32_IQ)(high_new << 2);

    reg64 = _mpy32ll(Dnorm, high1);
    high1 = (I32_IQ)_hill(reg64);


    high1 = 0x60000000 - high1;   //1.5 - Yn*Yn*V/2
    reg64 = _mpy32ll(yn_new,high1);
    high1 = (I32_IQ)_hill(reg64);
    high_new = high1;
    high1 = (I32_IQ)(high_new << 2);

    yn_new = high1;
    reg64 = _mpy32ll(yn_new, yn_new);
    high1 = (I32_IQ)_hill(reg64);
    high_new = high1;
    high1 = (I32_IQ)(high_new << 2);

    reg64 = _mpy32ll(Dnorm, high1);
    high1 = (I32_IQ)_hill(reg64);


    high1 = 0x60000000 - high1;   //1.5 - Yn*Yn*V/2
    reg64 = _mpy32ll(yn_new, high1);
    high1 = (I32_IQ)_hill(reg64);
    high_new = high1;
    high1 = (I32_IQ)(high_new << 2);



    reg64 = _mpy32ll(high1, Dnorm);
    high1 =(I32_IQ) _hill(reg64);

    nn =(U16_IQ)( n << 15);
    if(nn != 0) //n & 0x01
    {
        reg64 = _mpy32ll(high1, 0x20000000);           // 0.5 .......IQsqrtRoundSatTable[6]
    }

    else
    {
        reg64 = _mpy32ll(high1, 0x2D413CCD);          // 1/sqrt(2) ..IQsqrtRoundSatTable[7]
    }

    high1 = (I32_IQ)_hill(reg64);
    low1 = _loll(reg64);



    /* =================================================== */
    /* Step(5):Denormalize result                          */
    /*        Y = Yn * 2^n / sqrt(2^n)                     */
    /* =================================================== */
    sbits = (U16_IQ)( n >> 1);
    /* shift right by sbits  */
    high_new = high1;
    res = _SHL(high_new, (32 - sbits));   // high_new << (32 - sbits);
    low1 >>= sbits;
    high_new = high1;
    high1 = (I32_IQ)(high_new >> sbits);
    low1  |= res;
    /* shift left by 4  bits */
    res = low1 >> (28);
    low1 <<= 4;
    high_new = high1;
    high_new <<= 4;
    high1 = (I32_IQ)(high_new | res);

    /* code for  _add64(&reg64,&t64);*/
    tmp1 = low1;
    tmp3 = tmp1 + tmp1;
    low1 = (U32_IQ)tmp3;
    high1 = _sadd(high1, high1);
    res = _hill(tmp3);  // (U32_IQ)((U64_IQ)tmp3 >> 32);
    high1  =  _sadd(high1, (I32_IQ)res);



    /* Rounding */
    res  = low1 >> 31;
    high1  =  _sadd(high1, (I32_IQ)res);


    return (high1);
}


/*###########################################################################
;;
;; FILE:    IQNmpy.c
;;
;; TITLE:   C-Model: _IQNmpy function
;;
;;===========================================================================
;; Function:   _IQNmpy
;;===========================================================================
;;
;; C Usage:    extern long _IQmpy(long M, long X);   // no round or sat
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = M in IQ format
;;             B4    = X in IQ format
;; On Exit:    A4    = M * X in IQ format
;;
;; Q range:    30 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The IQmpy operation generates a 64-bit result. The 64-bit
;;             number must then be scaled back to a 32-bit value with the 
;;             same Q value as the original inputs. For example: if Q = 27, 
;;             then the multiplication of two I5Q27 numbers results in the 
;;             following 64-bit value:
;;
;;                          I5Q27 * I5Q27 = I10Q54
;;
;;             The value is then scaled back to an I5Q27 value as follows:
;;
;;                          I5Q27 = I10Q54 >> Q
;;
;;             For some of the operations, the value is either rounded or
;;             saturated (or both) to its maximum value before scaling.
;;          
;;---------------------------------------------------------------------------*/


static inline I32_IQ _IQNmpy(I32_IQ f1, I32_IQ f2, U32_IQ q_format)
{

    I64_IQ res_64;
    U32_IQ res_hi, res_lo, res, res_1;
    const U32_IQ k1 =32u;

    res_64 =  _mpy32ll(f1, f2); //(int)f1 * (int)f2;

    res_lo = _loll(res_64);
    res_hi = _hill(res_64);

    /* Extract the 32 bit result from 64 bit. */
    res = res_lo >> q_format;
    res_1 = (res_hi << (k1 - q_format));

    res |= res_1;

    return((I32_IQ)res);

}

/*###########################################################################
;;
;; FILE:    IQNmpyI32frac.c
;;
;; TITLE:   C-Model: _IQNmpyI32frac function
;;
;;===========================================================================
;; Function:   _IQNmpyI32frac
;;===========================================================================
;;
;; C Usage:    extern long _IQmpyI32frac(long A, long B); // no round or sat
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = A in IQ format
;;             B4    = B in 32-bit integer format
;; On Exit:    A4    = fractional portion of A*B stored as IQ
;;                       
;; Q range:    30 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The fractional portion of the IQ*I32 number is calculated
;;             as follows:
;;
;;                fraction = A*B - ((A*B >> q_value) << q_value)
;;          
;;---------------------------------------------------------------------------*/



static inline I32_IQ _IQNmpyI32frac(I32_IQ x, I32_IQ y, U32_IQ qfmt)      
{


    U32_IQ res_lo,res_hi;
    I32_IQ ax,ay,reg64_hi;
    I64_IQ res_64;
    const U32_IQ k1 = 32U;
    

    ax = _abs(x);
    ay = _abs(y);

    res_64 = _mpy32ll(ax, ay);
    res_lo = _loll(res_64);
    
    res_lo = res_lo << (k1-qfmt);     // Check this.
    res_hi = res_lo >> (k1-qfmt);

    reg64_hi = (I32_IQ) (res_hi); 

//    if( (x<0 && y>0) || (x>0 && y<0))
    if( (x ^ y) >> 31 )   // If the sign bit is different.
    {
        reg64_hi = _ssub(0, reg64_hi);
    }

    return(reg64_hi);
}
/*###########################################################################
;;
;; FILE:    IQNmpyI32int.c
;;
;; TITLE:   C-Model: _IQNmpyI32int function
;;
;;===========================================================================
;; Function:   _IQNmpyI32int
;;===========================================================================
;;
;; C Usage:    extern long _IQmpyI32int(long A, long B); // with sat
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = A in IQ format
;;             A3    = B in 32-bit integer (long) format
;; On Exit:    A4    = integer portion of A*B stored as "long"
;;                       
;; Q range:    30 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The integer portion of the IQ*I32 number is calculated
;;             as follows:
;;
;;                integer = A*B >> q_value;
;;          
;;---------------------------------------------------------------------------*/



static inline I32_IQ _IQNmpyI32int(I32_IQ x, I32_IQ y, U32_IQ qfmt)       
{
   
    U32_IQ res_lo,res_hi,mbits,mask;
    I32_IQ ax,ay,reg64_hi;
    I64_IQ res_64;
    const U32_IQ k1 = 32U;
    
    ax=_abs(x);
    ay=_abs(y);
    

    res_64 = _mpy32ll(ax,ay);
    res_hi = _hill(res_64);
    res_lo = _loll(res_64);

    mask = (1 << qfmt)-1;   // Sada: Why not shift directly by (k1-qfmt)
    mbits = res_hi & mask;
    mbits = mbits << (k1-qfmt);


    res_hi = (res_hi) >> (qfmt-1);
    res_lo = (res_lo) >> qfmt;
    res_lo = mbits | res_lo;

    // Sada: Perform saturation. Probably "if(res_hi < 1)" to consder negative result.
    if((res_hi !=0 ))
    {
    res_lo = 2147483647u;//0x7fffffff;
    }

    reg64_hi = (I32_IQ) res_lo;

//    if( (x<0 && y>0) || (x>0 && y<0))
    if ( (x ^ y) >> 31 )   // If the sign bit is different.
    {
        reg64_hi = _ssub(0,reg64_hi);
    }
  
    return(reg64_hi);
}
/*###########################################################################
;;
;; FILE:    IQNmpyIQx.c
;;
;; TITLE:   C-Model: _IQNmpyIQx function
;;
;;
;; C Usage:    extern static inline I32_IQ _IQNmpyIQx(I32_IQ in1, I32_IQ qfmt1, I32_IQ in2,
;;                                      I32_IQ qfmt2, I32_IQ qfmt)
;;
;;---------------------------------------------------------------------------*/



static inline I32_IQ _IQNmpyIQx(I32_IQ in1, I32_IQ qfmt1, I32_IQ in2, I32_IQ qfmt2, U32_IQ qfmt)      
{
    I32_IQ scnt;
    I64_IQ reg64;
    I32_IQ high, high_new;
    U32_IQ res, low,scnt_new;
    const U32_IQ k1 = 32u;
    I32_IQ result;
    reg64 = _mpy32ll(in1, in2);
    low = _loll(reg64);
    high = (I32_IQ)_hill(reg64);
    scnt = ((I32_IQ)qfmt - qfmt1 - qfmt2);
    if(scnt > 0)
    {
        scnt_new = (U32_IQ)scnt;

        if(high == 0 || high == 0xffffffff)
        {
        low <<= scnt_new;
        }

        else
        {
         low = 2147483647u;//0x7fffffff;
         }
        result = (I32_IQ)low;

    }
    else 
    {

        scnt_new = (U32_IQ)(-scnt);
        high_new = high;
        if (scnt_new > 31) 
        {
            scnt_new =  scnt_new - 32u;
            low = high_new >> scnt_new;

                result = (I32_IQ)low;

        }
        else
        {

            high = (I32_IQ)high >> (scnt_new - 1);
            if(high == 0 || high == 0xffffffff){
                res = (high_new << (k1 - scnt_new));
                low >>= (scnt_new);
                low |=res;
            }
            else
            { low = 2147483647u;//0x7fffffff;

            }

                result = (I32_IQ)low;
        }

    }

    return (result);

}

          




   








/*###########################################################################
;;
;; FILE:    IQNpow.c
;;
;; TITLE:   IQ Power Math Function
;;

;;===========================================================================
;; Function:   _IQNpow
;;===========================================================================
;; C Usage:    extern int _IQNpow(I32_IQ x, I32_IQ y ,U32_IQ qfmt)
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = X in IQ format
;;             B4    = Y in IQ format
;; On Exit:    A4    = pow(X) result in IQ format
;;
;; Q range:    29 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The procedure for calculating "Y = exp(X)" is as follows:
;;
;;             Step 1)  take abs value of x
;; 
;;             Step 2)  Algorithm: 
;;
;;                     z = x pow(y)
;;                     log z = y * log x
;;                     z = exp(y * log (x))
;;
;;--------------------------------------------------------------------------*/





static inline I32_IQ _IQNpow(I32_IQ x, I32_IQ y ,U32_IQ qfmt)
{
    I32_IQ ln_val,exp_val;
    
    I64_IQ reg;
    x =_abs (x);
    ln_val = _IQNlog(x, qfmt);
    reg= _mpy32ll(y,ln_val);
    reg >>= qfmt;
    y = _loll(reg);
    exp_val = _IQNexp(y, qfmt);
    return exp_val;

}
/*###########################################################################
;;
;; FILE:    IQNrmpy.c
;;
;; TITLE:   C-Model: _IQNrmpy function
;;
;;===========================================================================
;; Function:   _IQNrmpy
;;===========================================================================
;;
;; (for C64x+ processors )
;; C Usage:    extern int _IQNdiv(int M, int X);    //with rounding
;;
;; (for C28x processors )
;; C Usage:    extern long _IQmpy(long M, long X);
;;


;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = M in IQ format
;;             A4    = X in IQ format
;; On Exit:    ACC   = M * X in IQ format
;;
;; Q range:    30 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The IQmpy operation generates a 64-bit result. The 64-bit
;;             number must then be scaled back to a 32-bit value with the 
;;             same Q value as the original inputs. For example: if Q = 27, 
;;             then the multiplication of two I5Q27 numbers results in the 
;;             following 64-bit value:
;;
;;                          I5Q27 * I5Q27 = I10Q54
;;
;;             The value is then scaled back to an I5Q27 value as follows:
;;
;;                          I5Q27 = I10Q54 >> Q
;;
;;             For some of the operations, the value is either rounded or
;;             saturated (or both) to its maximum value before scaling.
;;          
;;---------------------------------------------------------------------------*/


static inline I32_IQ _IQNrmpy(I32_IQ x, I32_IQ y, U32_IQ qfmt)       
{
    I64_IQ reg64;
    I32_IQ hi, lo ,temp;
    Uword40 temp1, temp3 ;
    const U32_IQ k1 = 32u;
    /* =========================================================================*/
    /* multiply the inputs                                                      */          
    /* =========================================================================*/

    reg64 = _mpy32ll(x, y);
    temp1 = _loll(reg64);
    /* =========================================================================*/
    /* rounding of the answer obtained                                                                  */          
    /* =========================================================================*/

    temp3 = temp1 + ( 1 << (qfmt - 1) );  
    lo = (I32_IQ)temp3;
    hi =(I32_IQ)_hill(reg64);
    temp = (I32_IQ)_hill((I64_IQ)temp3);
    hi = _sadd(hi , temp);
    /* =========================================================================*/
    /* finally rescaling so that the q format maintained                        */          
    /* =========================================================================*/

    lo = (I32_IQ)((U32_IQ)lo >> qfmt) ;
    hi = (I32_IQ)hi << (k1 - qfmt) ;
    lo = lo + hi;
    return(lo);
}
/*###########################################################################
;;
;; FILE:    IQNrsmpy.c
;;
;; TITLE:   C-Model: _IQNrsmpy function
;;
;;===========================================================================
;; Function:   _IQNrsmpy
;;===========================================================================
;;
;; C Usage:    extern long _IQrsmpy(long M, long X);   // no round or sat
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = M in IQ format
;;             B4    = X in IQ format
;; On Exit:    A4    = M * X in IQ format
;;
;; Q range:    30 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The IQmpy operation generates a 64-bit result. The 64-bit
;;             number must then be scaled back to a 32-bit value with the 
;;             same Q value as the original inputs. For example: if Q = 27, 
;;             then the multiplication of two I5Q27 numbers results in the 
;;             following 64-bit value:
;;
;;                          I5Q27 * I5Q27 = I10Q54
;;
;;             The value is then scaled back to an I5Q27 value as follows:
;;
;;                          I5Q27 = I10Q54 >> Q
;;
;;             For some of the operations, the value is either rounded or
;;             saturated (or both) to its maximum value before scaling.
;;          
;;---------------------------------------------------------------------------*/




static inline I32_IQ _IQNrsmpy(I32_IQ x, I32_IQ y, U32_IQ qfmt)      
{
    I64_IQ reg64;
    I32_IQ high, acc;
    U32_IQ p, low, res,high_new;
    U64_IQ tmp1, tmp3;
    const U32_IQ k1 = 0xffffffff , k2 =32u;
    
    /* =========================================================================*/
    /* multiply the inputs                                                      */          
    /* =========================================================================*/

    reg64 = _mpy32ll(x, y);
    high = (I32_IQ)_hill(reg64);
    tmp1 = _loll(reg64);



    tmp3 = tmp1 + ( 1 << (qfmt-1) );  
    low = (U32_IQ)tmp3;
    acc = (I32_IQ)_hill((I64_IQ)tmp3);
    high = _sadd(high,acc );

    /* ======================================== */
    /* Checking for minimum of 2 64 bit numbers */
    /* ======================================== */

    acc = ((1 << (qfmt - 1)) - 1);
    p = 0xFFFFFFFF;

    if((high > acc) && (low <=  p) )
    {
        low = p;
        high = acc;
    }


    /* ======================================== */
    /* Checking for maximum of 2 64 bit numbers */
    /* ======================================== */ 
    
    acc = (I32_IQ)(k1 - acc);
    p = 0;

    if( high < acc)
    {
        low = p;
        high = acc;
    }

    /* ======================================================= */
    /* finally rescaling so that the q format maintained       */           
    /* ======================================================  */

    res = low >> (qfmt);
    high_new = high;
    high = (I32_IQ)(high_new << (k2 - qfmt));

    high_new = high;
    high = (I32_IQ)(high_new | res);

    return(high);
}
/*###########################################################################
;;
;; FILE:    _IQNsat.c
;;
;; TITLE:   C-Model: _IQNsat function
;;

;;===========================================================================
;; Function:   _IQNsat
;;===========================================================================
;;
;; C Usage:    _IQsat(int A);
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = A in IQ format
;; On Exit:    A4    = Saturated value of A in IQ format
;;                       
;; Q range:    31 to 0
;;
;;---------------------------------------------------------------------------
;; Algorithm:  Saturates the value "A" between the values "Pos" and "Neg".
;;          
;;--------------------------------------------------------------------------*/



static inline I32_IQ _IQNsat(I32_IQ A,U32_IQ qfmt)
{
    U32_IQ Pos;
    I32_IQ Neg;
    const U32_IQ k1 =31u;
    Pos=  ((1<<(k1 - qfmt)) - 1);
    Neg= -(1<<(k1 - qfmt));
    if( A > (I32_IQ)Pos )
    {
        A =(I32_IQ) Pos;
    } 
    if( A < Neg )
    {
        A = Neg;
    }
    return A;
}


/*###########################################################################
;;
;; FILE:    IQNsin.c
;;
;; TITLE:   C-Model: IQsin function
;;

;;===========================================================================
;; Function:   _IQNsin
;;===========================================================================
;;  (for C64x+ processors)  
;; C Usage:    extern int _IQNsin(int Rad);
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4 = Radian in IQ format
;;
;; On Exit:    A4 = sin(Radian) result in IQ format
;;
;; Q range:    29 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The "sin" value is calculated as follows:
;;
;;             1) The offset into a 512 word sin/cos table is calculated:
;;
;;                 k = 0x1FF & (int(Radian*512/(2*pi)))
;;                 
;;
;;             2) The fractional component between table samples is
;;                calculated:
;;
;;                 FRAC_PART = fract(Radian*512/2*pi) * (2*pi)/512
;;
;;             3) The output sine value is calculated as follows:
;;
;;                 sin(Radian) = S(k) + FRAC_PART*(C(k) + FRAC_PART*(-0.5*S(k) - 0.166*FRAC_PART*C(k)))
;;
;;                 where  S(k) = Sin table value at offset "k"
;;                        C(k) = Cos table value at offset "k"
;;
;;             Using the above method, with a 512x32 full wave sin/cos table,
;;             will give an accuracy of approximately 29 bits.
;;
;;---------------------------------------------------------------------------
;;=========================================================================*/





static inline I32_IQ _IQNsin(I32_IQ in, U32_IQ qfmt)
{
    const I32_IQ K = 0x2AAA;                    // 1/6 in Q16

    I64_IQ  reg64;
    I32_IQ  y, z, acc, acc1;
    U32_IQ x, hi, lo, offset, p;
    

    /* ======================================================================== */
    /*  K1 = (2 * pi) / 512 = 0x03243F6B (Q32)                                  */
    /*  K2 = 512 / (2 * pi) = 0x517CC1B7 (I8Q24)                                */
    /* ======================================================================== */

    const U32_IQ k1 = 0x03243F6BU, k2 = 0x517CC1B7U, k3 = 0x8U;  
    const U32_IQ k4 = 0x18U, k5 = 0x28U, k6 = 0x1EU;  

    /* ======================================================================== */
    /*  x = Radian * (512 / (2 * pi))                                           */
    /* ======================================================================== */

    y = _abs(in);                   //user format
    reg64 = _mpy32su(y, k2); 
    hi = _hill(reg64);
    lo = _loll(reg64);

    /* ======================================================================== */
    /*  seperating out the integer part and fractional part                     */
    /*  acc = integer part                                                      */
    /*  p = fractional part                                                     */
    /* ======================================================================== */
    acc =(I32_IQ)(hi >> (qfmt - k3));
    p = (hi << (k5 - qfmt));
    p += (lo >> (qfmt - k3));

    if(qfmt < 9)
    {
        acc = (I32_IQ)(hi << (k3 - qfmt));
        acc += (I32_IQ)(lo >> (k4 + qfmt));
        p = (lo << (k3 - qfmt));
    }

    /* ======================================================================== */
    /*  The offset into a 512 word sin/cos table is calculated                  */
    /* ======================================================================== */

    offset = (U32_IQ)acc & 0x1ffU;
    reg64 = _mpy32u(p, k1); 

    /* ======================================================================== */
    /*  sine value at the offset calculated                                     */
    /* ======================================================================== */

    z = -IQsinTable[offset];  

    /* ======================================================================== */
    /*  cosine value at the offset calculated                                   */
    /* ======================================================================== */

    y = IQsinTable[offset + 128U];    

    /* ======================================================================== */
    /*   frac_part * (-0.5 * S(k) - 0.166 * frac_part * C(k))                   */
    /*   maintained I1Q31 format throughout                                     */
    /* ======================================================================== */

    x = _hill(reg64);               // frac_part Q32
    reg64 = _mpy32us(x, y);  
    acc = (I32_IQ)z >> 1; 
    acc1 = (I32_IQ)_hill(reg64);                // -0.5 * S(k)
    acc1 = _mpyhl(acc1, K);   
    acc = acc - acc1;
    reg64 = _mpy32us(x, acc); 
    acc1 = (I32_IQ)_hill(reg64) + y; 

    /* ======================================================================== */
    /*   ACC = S(k) + x * (C(k) + x * (-0.5 * S(k) - 0.166 * x * C(k)))         */  
    /*   maintained I1Q31 format                                                */
    /* ======================================================================== */

    reg64 = _mpy32us(x, acc1);
    acc = (I32_IQ)_hill(reg64) - z;  
    /* ======================================================================== */
    /*  applying                                                                */
    /*  sin(-alpha)=-sin(alpha)                                                 */
    /* ======================================================================== */

    if(in < 0)
    {
        acc = -acc;
    }

    /* ======================================================================== */
    /*  rescaling back to the user defined Q format                             */  
    /* ======================================================================== */

    acc = (I32_IQ)acc >> (k6 - qfmt);
    return(acc);

}



/* ============================================================================ */
/*  End of file:  IQNsin.c                                                    */
/* ---------------------------------------------------------------------------- */
/*            Copyright (c) 2006 Texas Instruments, Incorporated.               */
/*                           All Rights Reserved.                               */
/* ============================================================================ */
/*###########################################################################
;;
;; FILE:    IQNsinPU.c
;;
;; TITLE:   C-Model: IQsinPU function
;;

;;===========================================================================
;; Function:   _IQNsinPU
;;===========================================================================
;;(for C28x processor)
;; C Usage:    extern long _IQNsinPU(long PU);
;;(for C64x+ processor)
;; C Usage:    extern int _IQNsinPU(int PU);
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4 = Per Unit in IQ format

;; On Exit:    A4 = sin(PU) result in IQ format
;;
;; Q range:    29 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The "sinPU" value is calculated as follows:
;;
;;             1) The offset into a 512 word sin/cos table is calculated:
;;
;;                 k = 0x1FF & (int(PU*512))
;;                 
;;
;;             2) The fractional component between table samples is
;;                calculated:
;;
;;                 x = fract(PU*512) * (2*pi)/512
;;
;;             3) The output sine value is calculated as follows:
;;
;;                 sin(PU) = S(k) + x*(C(k) + x*(-0.5*S(k) - 0.166*x*C(k)))
;;
;;                 where  S(k) = Sin table value at offset "k"
;;                        C(k) = Cos table value at offset "k"
;;
;;             Using the above method, with a 512x32 full wave sin/cos table,
;;             will give an accuracy of approximately 29 bits.
;;
;;--------------------------------------------------------------------------*/



static inline I32_IQ _IQNsinPU(I32_IQ in, U32_IQ qfmt)        
{
    const I32_IQ K = 0x2AAA;                    // 1/6 in Q16

    I64_IQ  reg64;
    I32_IQ  y, z, acc, acc1;
    U32_IQ x, hi, offset, p;
  
    /* ======================================================================== */
    /*  K1 = (2 * pi) / 512 = 0x03243F6B (Q32)                                  */
    /* ======================================================================== */

    const U32_IQ k1 = 0x03243F6BU, k3 = 0x9U;  
    const U32_IQ k5 = 0x29U, k6 = 0x1EU;  
   /* ======================================================================== */
    /*  x = Radian * (512 / (2 * pi))                                           */
    /* ======================================================================== */

    hi = _abs(in);                   //user format

    /* ======================================================================== */
    /*  seperating out the integer part and fractional part                     */
    /*  acc = integer part                                                      */
    /*  p = fractional part                                                     */
    /* ======================================================================== */

    acc = (I32_IQ)(hi >> (qfmt - k3));
    p = (hi << (k5 - qfmt));

    if(qfmt < 9)
    {
        acc =(I32_IQ)(hi << (k3 - qfmt));
        p = 0;
    }


    /* ======================================================================== */
    /*  The offset into a 512 word sin/cos table is calculated                  */
    /* ======================================================================== */

    offset = (U32_IQ)acc & 0x1ffU;
    reg64 = _mpy32u(p, k1); 

    /* ======================================================================== */
    /*  sine value at the offset calculated                                     */
    /* ======================================================================== */

    z = -IQsinTable[offset];  

    /* ======================================================================== */
    /*  cosine value at the offset calculated                                   */
    /* ======================================================================== */

    y = IQsinTable[offset + 128U];    

    /* ======================================================================== */
    /*   frac_part * (-0.5 * S(k) - 0.166 * frac_part * C(k))                   */
    /*   maintained I1Q31 format throughout                                     */
    /* ======================================================================== */

    x = _hill(reg64);               // frac_part Q32
    reg64 = _mpy32us(x, y);  
    acc = (I32_IQ)z >> 1; 
    acc1 = (I32_IQ)_hill(reg64);                // -0.5 * S(k)
    acc1 = _mpyhl(acc1, K);   
    acc = acc - acc1;
    reg64 = _mpy32us(x, acc); 
    acc1 = (I32_IQ)_hill(reg64) + y; 

    /* ======================================================================== */
    /*   ACC = S(k) + x * (C(k) + x * (-0.5 * S(k) - 0.166 * x * C(k)))         */  
    /*   maintained I1Q31 format                                                */
    /* ======================================================================== */

    reg64 = _mpy32us(x, acc1);
    acc = (I32_IQ)_hill(reg64) - z;  

    /* ======================================================================== */
    /*  applying                                                                */
    /*  sin(-alpha)=-sin(alpha)                                                 */
    /* ======================================================================== */

    if(in < 0)
    {
        acc = -acc;
    }
    /* ======================================================================== */
    /*  rescaling back to the user defined Q format                             */  
    /* ======================================================================== */

    acc = (I32_IQ)acc >> (k6 - qfmt);
    return(acc);

}



/* ============================================================================ */
/*  End of file:  IQNsin.c                                                    */
/* ---------------------------------------------------------------------------- */
/*            Copyright (c) 2006 Texas Instruments, Incorporated.               */
/*                           All Rights Reserved.                               */
/* ============================================================================ */
/*###########################################################################
;;
;; FILE:    IQNsqrt.c
;;
;; TITLE:   C-Model: _IQNsqrt function
;;
;;===========================================================================
;; Function:   _IQNsqrt
;;===========================================================================
;;
;; C Usage:    extern long _IQNsqrt(long X);   // with rounding
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = X in IQ format
;; On Exit:    A4    = sqrt(X) result in IQ format
;;             A4    = 0 if input is -ve or 0
;;
;;                      Note: The square root of any number will never
;;                            overflow, hence saturation is not required.
;;
;; Q range:    30 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The procedure for calculating "Y = sqrt(X)" is similar
;;             to calculating the inverse sqare root due to the
;;             following relationship:
;;
;;                     sqrt(X) = X * 1/sqrt(X)
;;
;;             The procedure is as follows:
;;
;;             Step 1) Normalize Input:
;;
;;                     V = X * 2^n
;;
;;             Step 2) Obtain initial estimate from "_IQsqrtTable"
;;                     using the upper 8-bits of the normalized V value.
;;
;;             Step 3) Use Newton-Raphson algorithm to improve accuracy.
;;                     Repeat following equation two times. First iteration
;;                     gives 16-bit accuracy. Second iteration gives 32-bit
;;                     accuracy:
;;
;;                     Yn = Yn(1.5 - Yn*Yn*V/2)
;;
;;                     Yn = 1/sqrt(V)
;;
;;             Step 4) Caculate the square root of the normalized number:
;;
;;                     Yn = V * Yn
;;
;;             Step 5) Denormalize result and round:
;;
;;                     Y = Yn * 2^n / sqrt(2^n)
;;
;;---------------------------------------------------------------------------*/




 static inline I32_IQ _IQNsqrt(I32_IQ x, U32_IQ qfmt)
{
    I64_IQ reg64;
    I32_IQ  high, Dnorm, yn_new=0;
    I16_IQ index_new;
    U16_IQ shift;
    U32_IQ sbits;
    U32_IQ res, low,high_new,z_qfmt,z_sbits;
    const U32_IQ k1 =22u , k2 = 23u , k3 =32u;


    /* Step(1):  Normalize Input: */

    sbits = _norm(x);
    high_new = x;
    Dnorm = (I32_IQ)(high_new << sbits);

    /* ==================================================== */
    /* Step(2): Obtain initial estimate from "_IQsqrtTable" */
    /*  using the upper 8-bits of the normalized V value.   */
    /* ==================================================== */

    if(Dnorm > 0){
        index_new = (I16_IQ)(((U32_IQ)Dnorm) >> 23);
        index_new = (I16_IQ)(index_new - 127);
        yn_new = IQisqrtTable[index_new];
    }

    /* yn has initial estimae */

    /* ============================================================ */
    /* Step(3):Use Newton-Raphson algorithm to improve accuracy.    */
    /*    Repeat following equation two times. First iteration      */
    /*    gives 16-bit accuracy. Second iteration gives 32-bit      */
    /*    accuracy:                                                 */
    /*                     Yn = Yn(1.5 - Yn*Yn*V/2)                 */
    /*                     Yn = 1/sqrt(V)                           */
    /* ============================================================ */

    reg64 = _mpy32ll(yn_new, yn_new);
    high = (I32_IQ)_hill(reg64);
    low = 0;
    high_new = high;
    high = (I32_IQ)(high_new << 2);
    reg64 = _mpy32ll(Dnorm, high);
    high = (I32_IQ)_hill(reg64);


    high = 0x60000000 - high;   //1.5 - Yn*Yn*V/2
    reg64 = _mpy32ll(yn_new, high);
    high = (I32_IQ)_hill(reg64);
    high_new = high;
    high = (I32_IQ)(high_new << 2);



    yn_new = high;
    reg64 = _mpy32ll(yn_new, yn_new);
    high = (I32_IQ)_hill(reg64);
    high_new = high;
    high = (I32_IQ)(high_new << 2);

    reg64 = _mpy32ll(Dnorm, high);
    high = (I32_IQ)_hill(reg64);


    high = 0x60000000 - high;   //1.5 - Yn*Yn*V/2
    reg64 = _mpy32ll(yn_new, high);
    high = (I32_IQ)_hill(reg64);
    high_new = high;
    high = (I32_IQ)(high_new << 2);

    reg64 = _mpy32ll(Dnorm, high);
    high = (I32_IQ)_hill(reg64);


    /*  ===========================================================  */
    /*  Step(4):Caculate the square root of the normalized number:   */
    /*         Yn = V * Yn                                           */
    /*  ===========================================================  */
    z_qfmt = qfmt << 31; 
    z_sbits = (I32_IQ)(sbits << 31);
    if(z_qfmt == 0) {                         // Qfmat == even.(qfmt & 0x1)
        if(z_sbits != 0)//sbits & 0x01
        {
            reg64 = _mpy32ll(high, 0x20000000);      // 0.5..IQsqrtRoundSatTable[6]
        }
        else
        {
            reg64 = _mpy32ll(high, 0x2D413CCD);      // 1/sqrt(2)..IQsqrtRoundSatTable[7]
        }
    }
    else {
        if(z_sbits != 0)
        {
            reg64 = _mpy32ll(high, 0x2D413CCD);      // 1/sqrt(2)..IQsqrtRoundSatTable[7]
        }
        else
        {
            reg64 = _mpy32ll(high, 0x40000000);      // 1.0..IQsqrtRoundSatTable[5]
        }
    }

    low = _loll(reg64);
    high = (I32_IQ)_hill(reg64);


    /* ===================================================  */
    /* Step(5):Denormalize result                           */
    /*         Y = Yn * 2^n / sqrt(2^n)                     */
    /* ===================================================  */

    if(qfmt >= 24){

        shift = (U16_IQ)((qfmt - k1) >> 1);
        res = low >> (32 - shift);
        low <<= shift;
        high_new = high;
        high = (I32_IQ)(high_new << shift);

        high_new = high;
        high = (I32_IQ)(high_new | res);

    }
    else{
        shift = (U16_IQ)((k2-qfmt)>>1);
        high_new = high;
        res = _SHL(high_new, (32 - shift));   //  (high_new << (32 - shift));

        low >>= shift;
         high = (I32_IQ)(high_new >> shift);

        low |= res;
    }


    sbits >>= 1;
    high_new = high;
    res = _SHL(high_new, (k3 - sbits));   //  (high_new << (k3 - sbits));

    low >>= sbits;

    high = (I32_IQ)(high_new >> sbits);

    low |= res;


    /* Rounding */
    res = low >> 31;
    high = _sadd(high, (I32_IQ)res);


    return (high);
}
/*;;###########################################################################
;;
;; FILE:    IQNtoF.c
;;
;; TITLE:   C Callable IQ to Float Math Function
;;
;;###########################################################################
;;

;;===========================================================================
;; Function:   _IQNtoF
;;===========================================================================
;;
;; C Usage:    extern float _IQtoF(int A);   // no round or sat
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4    = A in IQ format
;; On Exit:    A4    = IEEE 754 floating-point equivalent of A
;;                       
;; Q range:    31 to 0
;;
;;---------------------------------------------------------------------------
;; Algorithm:  This operation converts an IQ number to the equivalent
;;             IEEE 754 Single-Precision floating-point format. This
;;             format is shown below:
;;
;;              31  30        23 22                                 0
;;             +-----------------------------------------------------+
;;             | s |      e     |                 f                  |
;;             +-----------------------------------------------------+
;;
;;             Value = (-1)^s * 2^(e-127) * 1.f
;;
;;             where: e = 1 to 254, f = 0.000000000 to ~1.0
;;                    e = 0, f = 0, s = 0, Value = 0.0
;;                    e = 0 and f != 0 case cannot occur in IQ math
;;                    e = 255 case cannot occur in IQ math
;;          
;;--------------------------------------------------------------------------*/




static inline Fword32 _IQNtoF(I32_IQ input, U32_IQ qfmt)       
{
#ifdef _TMS320C6X 
    U32_IQ ah, al, sign, e, sbits;
     Fword32 output;

    /* ======================================================================== */
    /*  normalize the input                                                     */
    /* ======================================================================== */
    
    sbits = _norm(input);
    ah = (U32_IQ)input;
    ah = ah << sbits;

    /* ======================================================================== */
    /*  use the same value if input is positive else complement it              */
    /* ======================================================================== */
    
    al = ah ^ 0x7fffffffu;
    if((I32_IQ)al >= 0)
    {
        al = ah;
    }
    ah = al;

    /* ======================================================================== */
    /*  find the sbits depending upon the q-format and input                    */
    /* ======================================================================== */
    
    e = 127u + (30u - qfmt);
    sbits =  e - sbits;
    if( ah == 0 )
    {
        sbits = 0;
    }

    /* ======================================================================== */
    /*  arrange the sign,exponent and mantissa(16 bits) in the specified format */
    /* ======================================================================== */
    
    al = al << 2;
    al = al >> 9;
    sign = ah & 0x80000000u;
    ah = sbits;
    ah = ah << 23;
    al = al | ah | sign;
    output = _itof(al);
    return(output);
#else  /* _TMS320C6X */

    Fword32 res = (Fword32) ( (double)input / ((__int64)1 << qfmt) );
    return(res);

#endif /* _TMS320C6X */
}



/**###########################################################################
;;
;; FILE:    atoIQN.c
;;
;; TITLE:   C-Model: _atoIQN function
;;

;;===========================================================================
;; Function:   _atoIQN
;;===========================================================================
;;
;; C Usage:    extern int _atoIQ(const char *A);
;;
;;---------------------------------------------------------------------------
;;
;; On Entry:   A4 = pointer to character string
;;             A3 = q_value 
;; On Exit:    A4 = IQ value from string (0 if an error occured)
;;
;; Q Range:    31 to 1
;;
;;---------------------------------------------------------------------------
;; Algorithm:  The input string must only contain decimal characters
;;             '0' to '9' and the characters '-' for negative value
;;             if applicable and '.' character for delimiting integer and
;;             fraction components. Some examples of valid inputs are:
;;
;;                        12.23456
;;                       -12.23456
;;                         0.2345
;;                         0.0
;;                         0
;;                       127
;;                       -89 
;;              
;;             If the input string converts to a number greater then
;;             the max/min values for the given Q value, then the returned
;;             value will be limited to the min/max values.
;;
;;             If the string contains illegal characters, it will return 
;;             the value zero.
;;
;;---------------------------------------------------------------------------
;; Benchmark:
;;      Cycles = Can be approximately from 200 to 800 cycles based on number 
;;               of characters in string.
;;
;;===========================================================================*/



//static inline I32_IQ _atoIQN(const char *A, U32_IQ q_value)       
//{
//const I32_IQ c1 ((I32_IQ)(0xffffffff))
//const I64_IQ c2 ((I64_IQ)(0xffffffff80000000))
//const I64_IQ c3 ((I64_IQ)(0x7fffffff))
//const I32_IQ c4 ((I32_IQ)(0x80000000))
//const unsigned int c5 ((0xffffffff))
//const unsigned int c6 ((0x80000000))
// 
//    Uchar8 arr[20];
//    Uword40 tmp1, tmp2, tmp3;
//    I64_IQ reg, t;
//    U32_IQ round1, res, pp, sf, si, data, temp1;
//    I32_IQ i64l=0, i64h=0, acc, tacc, imp=1;
//    U32_IQ f64l=0, f64h=0, p, tp, nrfdigits=0, i=0, j=0, temp=32u;
//    U16_IQ neg_flag = 0;
//    sf = 0x1999999Au;          // sf= 0.1 * 2^32 = scale frac
//    si = 10u;                  // si= 10 = scale int
//
//    /* ======================================================================== */
//    /*  Create an array of the character string                                 */
//    /* ======================================================================== */
//    
//    if(A != '\0')
//    {
//        while(A[j] != 0)
//        {
//            arr[i++] = A[j];
//            j++;
//        }
//    }
//    arr[i++] = 0;
//    i = 0;
//    data = arr[i];
//
//    /* ======================================================================== */
//    /*  operation on integer bits                                               */
//    /* ======================================================================== */
//   
//    while((data != 0) && (data != '.'))
//    {
//        if(data == '-')// _atoIQneg
//        {    
//            if(neg_flag != 0u)
//            {
//                imp = 0;
//            }
//            i++;
//            data = arr[i];
//            neg_flag = 1;
//        }
//        if((data < '0') || (data > '9'))  // _atoIQerror
//        {
//            imp = 0;
//        }
//        data = data - '0';
//        reg = _mpy32u(si, (U32_IQ) i64l);
//        p = _loll(reg);
//        acc = (I32_IQ) p + (I32_IQ) data;
//        p = _hill(reg);
//        i64l = acc;
//        acc = _mpy32((I32_IQ) si, i64h);
//        i64h = acc + (I32_IQ) p;
//        i++;
//        data = arr[i];
//    }
//    i++;
//
//    /* ======================================================================== */
//    /*  operation on fractional bits                                            */
//    /* ======================================================================== */
//
//    if(data == '.') // _atoIQdot
//    {  
//        while(data != 0)// Search for end of string and count frac characters:
//        {
//            nrfdigits++;
//            data = arr[i];
//            i++;
//            if((data < '0') || (data > '9'))  // _atoIQerror
//            {
//                imp = 0;
//            }
//                data = arr[i];
//        }
//
//        //_atoIQfrac:
//        i--;
//        if(nrfdigits >= 10)
//        {
//            nrfdigits = nrfdigits - 10u;
//            i = i - nrfdigits;
//        }
//        data = arr[i];
//        while(data != '.') 
//        {
//            data = data - '0';
//            f64h = (data << 16) | (f64h & 0xffffu);
//            reg = _mpy32u(sf, f64l);
//            p = _hill(reg);
//            reg = _mpy32su((I32_IQ) sf, f64h);
//            tp = _loll(reg);
//            tacc = 0;
//            acc =(I32_IQ) _hill(reg);
//            tmp1 = (Uword40) p;
//            tmp2 = (Uword40) tp;
//            tmp3 = tmp1 + tmp2;
//            p = (U32_IQ) tmp3;
//            acc = _sadd(acc, tacc);
//            round1 = (U32_IQ) _SHR(tmp3, temp);   // (tmp3 >> temp)
//            acc = _sadd(acc, (I32_IQ) round1);
//            f64l = p;
//            f64h = (U32_IQ) acc;
//            i--;
//            data = arr[i];
//        }
//    }
//
//    /* ======================================================================== */
//    /*  combine the integer and fractional parts to get IQvalue                                */
//    /* ======================================================================== */
//
//    /* Right Shift by 16 */
//    p = _packlh2(f64h, f64l);
//     
//    /* Right Shift by 32-qfmt */
//    pp = p;
//    temp1 = (U32_IQ) i64l;
//    res = temp1 << q_value;
//    i64l = (I32_IQ) _SHR(temp1, (temp - q_value));  // (temp1 >> (temp - q_value));
//    pp = _SHR(pp, (temp - q_value));    //  pp >>(temp - q_value);
//    pp = pp | res;
//    p = pp;
//    acc = (I32_IQ) p;
//
//    /* Negating if condition is true */
//    if(neg_flag == 1)
//    {
//        if((i64l == c4) && (acc == 0))
//        {
//            i64l = 0x7fffffff;
//            acc = c1;
//        }
//        else 
//        {
//        acc = (I32_IQ) (~(U32_IQ) acc);
//        i64l = (I32_IQ) ((U32_IQ) i64l ^ (U32_IQ) c1);
//        if(acc == c1)
//        {
//            i64l++;
//        }
//        acc = acc + 1;
//        }
//    }
//    t = c3;
//
//    /* Checking for minimum of two 64 bit numbers */
//    if((i64l > 0) || ((acc >= t)))
//    {
//        acc = (I32_IQ) t;
//        i64l = 0;
//    }
//    t = c2;
//
//    /* Checking for maximum of two 64 bit numbers */
//    if( i64l < c1)
//    {
//        acc = c4;
//        i64l = c1;
//    }
//    acc = (acc * imp);
//    return(acc);
//}

        

#endif /* __IQMATH_INLINE_H__ */

/* ======================================================================== */
/*            Copyright (c) 2007 Texas Instruments, Incorporated.           */
/*                           All Rights Reserved.                           */
/* ======================================================================== */

